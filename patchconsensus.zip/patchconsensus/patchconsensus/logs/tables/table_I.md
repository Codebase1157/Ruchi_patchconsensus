## TABLE I

Datasets and protocols (counts after deduplication) [REFERENCE]

| Dataset | Images (train/val/test) | Masks | Split unit | Role |
| --- | --- | --- | --- | --- |
| HAM10000 | 7010 / 1001 / 2004 | semi-auto. | lesion | Main benchmark |
| ISIC 2018 | 1886 / 269 / 539 | manual | patient | Second benchmark |
| PH2 | – / – / 200 | manual | – | External test |
| ISIC 2024 | – / – / 1000 | ours | – | External test, 3D TBP |

> HAM10000 split 70/10/20 by lesion, stratified by diagnosis.
