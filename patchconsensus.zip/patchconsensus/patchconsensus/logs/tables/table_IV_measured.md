## TABLE IV_measured

Ablation on HAM10000 (Table IV).

| # | Variant | Dice | HD95 | B-IoU | ECE | Eart | source |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | Single encoder (EoMT) | 91.79 | 9.15 | 65.1 | 0.062 | 1.0 | expected (paper) |
| 2 | Encoder-only fusion (M=3, P=1) | 92.71 | 8.06 | 67.2 | 0.048 | 0.84 | expected (paper) |
| 3 | Patch-only fusion (M=1, P=4) | 92.86 | 7.59 | 72.4 | 0.046 | 0.23 | expected (paper) |
| 4 | DACQ without dual variables | 93.57 | 5.87 | 73.5 | 0.035 | 0.24 | expected (paper) |
| 5 | DACQ + uniform fusion | 93.72 | 5.65 | 74.0 | 0.033 | 0.21 | expected (paper) |
| 6 | DACQ + diagonal reliability | 93.94 | 5.12 | 74.8 | 0.03 | 0.19 | expected (paper) |
| 7 | Full PatchConsensus | 93.98 | 5.05 | 74.9 | 0.029 | 0.18 | expected (paper) |
