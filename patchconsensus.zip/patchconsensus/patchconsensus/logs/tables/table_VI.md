## TABLE VI

Tests of assumptions A1-A5 (simulated held-out data, mirroring Section VII-E), with 95% bootstrap intervals over images

| Assumption | Test statistic | Measured | Accept if | Pass |
| --- | --- | --- | --- | --- |
| A1 | mean / s.d. of residual, per encoder | 0.016 [0.014, 0.018] | |.| < 0.05 | yes |
| A2, content | max. corr. of c_m and c_m' | 0.176 [0.172, 0.181] | < 0.3 | yes |
| A2, position | max. corr. of a_m and a_m' | 0.046 [0.044, 0.049] | < 0.3 | yes |
| A3 | corr. of position residuals at offset tau | 0.092 [0.087, 0.098] | < 0.1 | yes |
| A4 | max. corr. among components and with ell_GT | 0.043 [0.038, 0.046] | < 0.1 | yes |
| A5 | coeff. of variation of local variance | 0.193 [0.165, 0.221] | < 0.25 | yes |

> A3 is borderline near 0.1 (positional embeddings carry structure at several scales); its effect on Theorem 1 is bounded and one-directional (Section V-D).
