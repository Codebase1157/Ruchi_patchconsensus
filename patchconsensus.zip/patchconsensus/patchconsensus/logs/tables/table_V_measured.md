## TABLE V_measured

Design sweeps on HAM10000 (Table V).

| Factor | Setting | Dice | HD95 | Eart | Δrel | img/s | source |
| --- | --- | --- | --- | --- | --- | --- | --- |
| encoders | DINOv3 | 92.86 | 7.59 | 0.23 | – | 46.0 | expected (paper) |
| encoders | DINOv2 + DINOv3 | 93.12 | 6.7 | 0.19 | 0.04 | 23.0 | expected (paper) |
| encoders | DINOv3 + PanDerm | 93.67 | 5.85 | 0.19 | 0.06 | 23.0 | expected (paper) |
| encoders | all three | 93.98 | 5.05 | 0.18 | 0.26 | 15.3 | expected (paper) |
| stride | S (P=1) | 92.71 | 8.06 | 0.84 | – | 61.3 | expected (paper) |
| stride | S/2 (P=4) | 93.98 | 5.05 | 0.18 | 0.26 | 15.3 | expected (paper) |
| stride | S/4 (P=16) | 94.36 | 4.37 | 0.05 | 0.27 | 3.8 | expected (paper) |
| depth_L2 | 1 | 93.86 | 5.22 | 0.21 | 0.28 | 15.3 | expected (paper) |
| depth_L2 | 4 | 93.98 | 5.05 | 0.18 | 0.26 | 15.3 | expected (paper) |
| depth_L2 | 6 | 93.97 | 5.07 | 0.19 | 0.26 | 15.3 | expected (paper) |
