## TABLE III

Cross-dataset generalization: Dice (%), mean ± s.d. over five seeds. [REFERENCE]

| Train | Method | HAM10000 | ISIC 2018 | PH2 | ISIC 2024 |
| --- | --- | --- | --- | --- | --- |
| HAM10000 | EoMT | 91.8±0.3 | 90.2±0.4 | 91.6±0.7 | 81.0±0.3 |
| HAM10000 | EoSeg | 91.8±0.4 | 90.3±0.5 | 91.8±0.6 | 81.2±0.4 |
| HAM10000 | Ours | 94.0±0.2 | 92.7±0.3 | 94.2±0.4 | 84.1±0.2 |
| ISIC 2018 | EoMT | 91.1±0.5 | 90.9±0.4 | 91.7±0.7 | 81.1±0.4 |
| ISIC 2018 | EoSeg | 91.2±0.5 | 91.0±0.4 | 91.8±0.6 | 81.3±0.4 |
| ISIC 2018 | Ours | 93.7±0.3 | 93.1±0.3 | 94.2±0.4 | 84.2±0.2 |

> Trained on HAM10000, mean drop on 3 unseen sets: Ours 3.65, EoMT 4.19, EoSeg 4.09.
