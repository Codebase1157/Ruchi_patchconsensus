## TABLE VII

Teacher-student comparison on HAM10000. One 896x896 image, batch 1, FP32, A100 80GB. [REFERENCE]

| Metric | EoMT | Teacher | Student L | Student B |
| --- | --- | --- | --- | --- |
| Dice (%) | 91.8±0.3 | 94.0±0.2 | 93.4±0.2 | 92.8±0.2 |
| IoU (%) | 84.2±0.4 | 88.1±0.2 | 86.9±0.3 | 86.0±0.3 |
| HD95 (px) | 9.15±0.85 | 5.05±0.32 | 6.67±0.38 | 7.58±0.44 |
| Latency (ms) | 86 | 742 | 89 | 31 |
| Peak memory (GB) | 5.1 | 21.4 | 5.2 | 2.3 |
| GFLOPs | 1180 | 7290 | 1184 | 402 |
| Parameters (M) | 309 | 1048 | 312 | 94 |

> ViT-L student keeps 71% of the teacher's gain over EoMT at 8.3x the teacher's speed; ViT-B keeps 47% at 23.9x.
