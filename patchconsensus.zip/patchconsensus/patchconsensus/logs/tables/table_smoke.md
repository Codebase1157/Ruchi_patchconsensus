## TABLE smoke

Synthetic smoke test: fusion vs baselines (one image)

| Variant | Dice | IoU | HD95 | Boundary IoU |
| --- | --- | --- | --- | --- |
| Single encoder (M=1, P=1) | 91.61 | 84.52 | 17.53 | 15.22 |
| Uniform fusion | 97.08 | 94.33 | 4.47 | 39.33 |
| PatchConsensus (min-variance) | 97.23 | 94.60 | 3.61 | 42.64 |

> E_art relative to single encoder: fused = 0.628 (lower is better; patch fusion removes grid-aligned artifacts).
> Synthetic demonstration of Algorithm 1; not the paper's HAM10000 numbers.
