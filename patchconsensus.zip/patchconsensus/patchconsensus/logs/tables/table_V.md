## TABLE V

Design sweeps on HAM10000 (mean over five seeds). Defaults marked *. [REFERENCE]

| Factor | Setting | Dice | HD95 | Eart | Δrel | img/s |
| --- | --- | --- | --- | --- | --- | --- |
| Encoders | DINOv3 | 92.86 | 7.59 | 0.23 | – | 46.0 |
| Encoders | DINOv2 + DINOv3 | 93.12 | 6.70 | 0.19 | +0.04 | 23.0 |
| Encoders | DINOv3 + PanDerm | 93.67 | 5.85 | 0.19 | +0.06 | 23.0 |
| Encoders | all three* | 93.98 | 5.05 | 0.18 | +0.26 | 15.3 |
| Stride | S (P=1) | 92.71 | 8.06 | 0.84 | – | 61.3 |
| Stride | S/2 (P=4)* | 93.98 | 5.05 | 0.18 | +0.26 | 15.3 |
| Stride | S/4 (P=16) | 94.36 | 4.37 | 0.05 | +0.27 | 3.8 |
| Depth L2 | 1 | 93.86 | 5.22 | 0.21 | +0.28 | 15.3 |
| Depth L2 | 4* | 93.98 | 5.05 | 0.18 | +0.26 | 15.3 |
| Depth L2 | 6 | 93.97 | 5.07 | 0.19 | +0.26 | 15.3 |

> Δrel = Dice gain of reliability weighting over uniform: +0.04/+0.06 at M=2, +0.26 at M=3 (matches Proposition 2).
