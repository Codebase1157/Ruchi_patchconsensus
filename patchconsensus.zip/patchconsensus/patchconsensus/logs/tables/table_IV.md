## TABLE IV

Ablation on HAM10000 (mean ± s.d. over five seeds). Eart relative to single-encoder EoMT. [REFERENCE]

| # | Variant | Dice | HD95 | B-IoU | ECE | Eart |
| --- | --- | --- | --- | --- | --- | --- |
| 1 | Single encoder (EoMT) | 91.79±0.31 | 9.15±0.85 | 65.1±0.5 | 0.062 | 1.00 |
| 2 | Encoder-only fusion (M=3, P=1) | 92.71±0.26 | 8.06±0.71 | 67.2±0.4 | 0.048 | 0.84 |
| 3 | Patch-only fusion (M=1, P=4) | 92.86±0.24 | 7.59±0.63 | 72.4±0.4 | 0.046 | 0.23 |
| 4 | DACQ without dual variables | 93.57±0.22 | 5.87±0.47 | 73.5±0.3 | 0.035 | 0.24 |
| 5 | DACQ + uniform fusion | 93.72±0.19 | 5.65±0.44 | 74.0±0.3 | 0.033 | 0.21 |
| 6 | DACQ + diagonal reliability | 93.94±0.18 | 5.12±0.37 | 74.8±0.3 | 0.030 | 0.19 |
| 7 | Full PatchConsensus | 93.98±0.17 | 5.05±0.32 | 74.9±0.2 | 0.029 | 0.18 |

> Eart: EoMT+DVT 0.31, Gaussian sliding-window 0.29, metric-guided fusion 0.80, full 0.18.
