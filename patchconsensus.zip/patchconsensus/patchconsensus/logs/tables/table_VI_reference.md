## TABLE VI_reference

Tests of assumptions A1-A5 on held-out data, with 95% bootstrap intervals. [REFERENCE — paper values]

| Assumption | Test statistic | Measured | Accept if |
| --- | --- | --- | --- |
| A1 | mean / s.d. of residual, per encoder | 0.038 [0.034, 0.043] | |·| < 0.05 |
| A2, content | max. corr. of cm and cm' | 0.160 [0.149, 0.171] | < 0.3 |
| A2, position | max. corr. of am and am' | 0.038 [0.034, 0.042] | < 0.3 |
| A3 | corr. of position residuals at offset τ | 0.093 [0.082, 0.104] | < 0.1 |
| A4 | max. corr. among components and with ℓGT | 0.049 [0.045, 0.053] | < 0.1 |
| A5 | coeff. of variation of local variance | 0.226 [0.211, 0.243] | < 0.25 |

> A3 holds only marginally (0.093 vs 0.1 threshold); effect bounded (Section V-D).
