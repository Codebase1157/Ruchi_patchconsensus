# Theory validation report

Seeds: 10. Each check runs on independent Monte-Carlo draws.

| Check | Pass rate |
| --- | --- |
| T1a Eq(18): measured==wᵀΣw==decomposition | 10/10 |
| T1b Eq(19): uniform-weight error | 10/10 |
| T1c Thm1(c): min-variance == (1ᵀΣ⁻¹1)⁻¹ and is optimal | 10/10 |
| T1d Thm1(a): P=1 floor≥σ0²,  M=1 floor≥σc,1² | 10/10 |
| P2a M≥3,P≥2: recover σ0², σa,m², σc,m² (3-cornered hat) | 10/10 |
| P2 Eq(12): D_enc, D_pat, D_crs match closed forms | 10/10 |
| P2c P=1: σ0² flagged non-identifiable | 10/10 |
| P2b M=2: only τ1+τ2 identified, individual τ_m not | 10/10 |
| L1/Prop3: z -> inverse-variance mean; primal residual -> 0 | 10/10 |
| L1: dual norm ||u_i|| largest for the most disagreeing source | 10/10 |
| Eq(10): reliability ρ_i smallest for the outlier source | 10/10 |

**11/11 checks passed on every seed.**