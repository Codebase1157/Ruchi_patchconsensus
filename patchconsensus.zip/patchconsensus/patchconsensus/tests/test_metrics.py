"""Tests for evaluation metrics (Section VI-C)."""
import numpy as np

from patchconsensus import metrics as M


def _disk(H=128, W=128, r=30, cx=64, cy=64):
    yy, xx = np.mgrid[0:H, 0:W]
    return ((xx - cx) ** 2 + (yy - cy) ** 2 < r ** 2).astype(np.uint8)


def test_dice_iou_perfect():
    m = _disk()
    assert abs(M.dice(m, m) - 1.0) < 1e-6
    assert abs(M.iou(m, m) - 1.0) < 1e-6


def test_dice_disjoint():
    a = _disk(cx=32); b = _disk(cx=96)
    assert M.dice(a, b) < 0.05


def test_hd95_zero_for_identical():
    m = _disk()
    assert M.hd95(m, m) == 0.0


def test_hd95_increases_with_shift():
    a = _disk(cx=64); b = _disk(cx=70)
    assert M.hd95(a, b) > 0


def test_boundary_iou_perfect():
    m = _disk()
    assert abs(M.boundary_iou(m, m) - 1.0) < 1e-6


def test_ece_range():
    rng = np.random.default_rng(0)
    probs = rng.random((64, 64))
    gt = (probs > 0.5).astype(np.uint8)
    e = M.ece(probs, gt)
    assert 0.0 <= e <= 1.0


def test_artifact_energy_detects_grid():
    """A field with a token-grid ripple has higher E_art than a smooth field."""
    H = W = 112; G = 28
    yy, xx = np.mgrid[0:H, 0:W]
    smooth = np.sin(2 * np.pi * xx / H)[None]
    grid = smooth + 0.8 * np.sin(2 * np.pi * xx / G)[None]
    assert M.artifact_energy(grid, token_size=G) > M.artifact_energy(smooth, token_size=G)
