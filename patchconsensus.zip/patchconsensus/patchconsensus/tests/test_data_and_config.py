"""Tests for split generation (Section VI-A) and config inheritance."""
import json

from patchconsensus.data.splits import make_lesion_split, make_patient_split, save_split, load_split
from patchconsensus.utils.config import deep_merge, apply_overrides


def _items(n=300):
    # 100 lesions, 3 images each, 3 diagnoses
    items = []
    for L in range(100):
        dx = ["mel", "nv", "bkl"][L % 3]
        for j in range(3):
            items.append((f"img_{L}_{j}", f"lesion_{L}", dx))
    return items


def test_lesion_split_no_leakage():
    """No lesion id appears in more than one split (group-wise splitting)."""
    items = _items()
    split = make_lesion_split(items, seed=0)
    lesion_of = {iid: lid for iid, lid, _ in items}
    groups = {s: {lesion_of[i] for i in ids} for s, ids in split.items()}
    assert groups["train"].isdisjoint(groups["val"])
    assert groups["train"].isdisjoint(groups["test"])
    assert groups["val"].isdisjoint(groups["test"])


def test_split_covers_all_images():
    items = _items()
    split = make_lesion_split(items, seed=1)
    total = sum(len(v) for v in split.values())
    assert total == len(items)


def test_split_is_deterministic():
    items = _items()
    assert make_lesion_split(items, seed=7) == make_lesion_split(items, seed=7)
    assert make_lesion_split(items, seed=7) != make_lesion_split(items, seed=8)


def test_save_load_roundtrip(tmp_path):
    split = make_patient_split([("a", "p1", None), ("b", "p1", None), ("c", "p2", None)], seed=0)
    p = tmp_path / "s.json"
    save_split(split, str(p), meta={"x": 1})
    assert load_split(str(p)) == split
    assert json.loads(p.read_text())["meta"]["x"] == 1


def test_deep_merge_and_overrides():
    base = {"a": 1, "model": {"encoders": ["x"], "Q": 8}}
    over = {"model": {"encoders": ["x", "y"]}}
    out = apply_overrides(base, over)
    assert out["model"]["encoders"] == ["x", "y"]
    assert out["model"]["Q"] == 8      # untouched key preserved
    assert out["a"] == 1
