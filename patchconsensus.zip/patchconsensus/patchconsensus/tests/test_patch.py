"""Tests for patch decomposition and location codes (Eq 1, 2, 5)."""
import numpy as np
import pytest

from patchconsensus.patch import PatchGrid, token_position, location_code


def test_grid_counts_paper_defaults():
    g = PatchGrid(896, 896, 448, 224)
    assert g.K == 9                      # 3x3 grid
    # an interior pixel is covered by 4 patches (Section IV-B)
    assert g.coverage((448, 448)) == 4
    # corners are covered by 1
    assert g.coverage((0, 0)) == 1


def test_coverage_map_matches_pointwise():
    g = PatchGrid(896, 896, 448, 224)
    cov = g.coverage_map()
    for x in [(0, 0), (448, 448), (100, 700), (895, 895)]:
        assert cov[x[1], x[0]] == g.coverage(x)


def test_stride_must_be_less_than_side():
    with pytest.raises(ValueError):
        PatchGrid(896, 896, 448, 448)


def test_token_position_bounds():
    G = 28
    assert token_position((0, 0), (0, 0), 16, G) == (0, 0)
    ux, uy = token_position((447, 447), (0, 0), 16, G)
    assert 0 <= ux < G and 0 <= uy < G


def test_location_code_shape_and_range():
    e = location_code((224, 448), S=448, H=896, W=896)
    assert e.shape == (3,)
    assert np.allclose(e, [224 / 896, 448 / 896, 448 / 896])
