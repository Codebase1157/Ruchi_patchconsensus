"""Tests for the consensus-ADMM core (Eq 7-10, Proposition 3, Lemma 1)."""
import numpy as np

from patchconsensus.dacq import ConsensusADMM, inverse_variance_mean, dacq_reference


def test_converges_to_inverse_variance_mean():
    """Lemma 1 corollary: with equal penalties z* is the inverse-variance mean."""
    rng = np.random.default_rng(0)
    y = rng.standard_normal((6, 3))
    s2 = rng.uniform(0.2, 2.0, 6)
    out = ConsensusADMM(y, s2, adaptive_rho=False).run(600)
    assert np.linalg.norm(out["z"] - inverse_variance_mean(y, s2)) < 1e-4


def test_primal_residual_decreases():
    rng = np.random.default_rng(1)
    y = rng.standard_normal((5, 2)); s2 = rng.uniform(0.3, 1.5, 5)
    h = ConsensusADMM(y, s2, adaptive_rho=False).run(300, record=True)["history"]["primal"]
    assert h[-1] < h[5] and h[-1] < 1e-3


def test_dual_flags_outlier():
    """Lemma 1: the most disagreeing source accumulates the largest ||u||."""
    rng = np.random.default_rng(2)
    y = rng.standard_normal((5, 2)); y[2] += 8.0
    s2 = np.ones(5)
    out = ConsensusADMM(y, s2, adaptive_rho=False).run(300)
    assert int(np.argmax(np.linalg.norm(out["u"], axis=1))) == 2


def test_adaptive_rho_downweights_outlier():
    """Eq (10): reliability ρ smallest for the outlier."""
    rng = np.random.default_rng(3)
    y = rng.standard_normal((5, 2)); y[0] += 8.0
    out = ConsensusADMM(y, np.ones(5), adaptive_rho=True, freeze_after=2).run(50)
    assert int(np.argmin(out["rho"])) == 0


def test_dacq_reference_default_blocks():
    """dacq_reference uses L2=4 unrolled blocks by default and returns a query."""
    rng = np.random.default_rng(4)
    y = rng.standard_normal((9, 4)); s2 = rng.uniform(0.3, 1.0, 9)
    z = dacq_reference(y, s2)
    assert z.shape == (4,)
