"""Tests for Theorem 1 closed forms (Eq 18, 19) and the Σ quadratic form (Eq 14)."""
import numpy as np

from patchconsensus.noise_model import NoiseParams
from patchconsensus import theory as T
from patchconsensus.reliability import source_covariance, min_variance_weights


def test_decomposition_equals_quadratic_form():
    """Eq (18): three-family decomposition == w^T Σ w for arbitrary weights."""
    sc = np.array([0.3, 0.5, 0.2]); sa = np.array([0.1, 0.08, 0.15]); s0 = 0.4
    M, P = 3, 4
    cov = source_covariance(sc, sa, s0, P)
    rng = np.random.default_rng(0)
    for _ in range(20):
        w = rng.random(M * P); w /= w.sum()
        decomp = T.theorem1_error(w, sc, sa, s0, P)
        quad = float(w @ cov @ w)
        assert abs(decomp - quad) < 1e-9


def test_uniform_weight_formula():
    """Eq (19): uniform weights give the closed-form error."""
    sc = np.array([0.3, 0.5, 0.2]); sa = np.array([0.1, 0.08, 0.15]); s0 = 0.4
    M, P = 3, 4
    w = np.full(M * P, 1.0 / (M * P))
    assert abs(T.theorem1_error(w, sc, sa, s0, P)
               - T.uniform_weight_error(sc, sa, s0, P)) < 1e-12


def test_min_variance_is_minimum():
    """Thm 1(c): w* attains (1^T Σ^-1 1)^-1 and nothing feasible beats it."""
    sc = np.array([0.3, 0.5, 0.2]); sa = np.array([0.1, 0.08, 0.15]); s0 = 0.4
    cov = source_covariance(sc, sa, s0, 4)
    w = min_variance_weights(cov)
    assert abs(w.sum() - 1) < 1e-9
    target = T.min_variance_error(cov)
    assert abs(float(w @ cov @ w) - target) < 1e-9
    rng = np.random.default_rng(1)
    for _ in range(500):
        wr = rng.random(cov.shape[0]); wr /= wr.sum()
        assert float(wr @ cov @ wr) >= target - 1e-9


def test_floors():
    """Thm 1(a): P=1 floor is σ0²; M=1 floor is σc,1²."""
    sc = np.array([0.3]); sa = np.array([0.1]); s0 = 0.4
    cov_p1 = source_covariance(np.array([0.3, 0.5]), np.array([0.1, 0.1]), s0, 1)
    assert T.min_variance_error(cov_p1) >= s0 - 1e-9
    cov_m1 = source_covariance(sc, sa, s0, 4)
    assert T.min_variance_error(cov_m1) >= sc[0] - 1e-9


def test_covariance_is_psd():
    cov = source_covariance([0.3, 0.5, 0.2], [0.1, 0.08, 0.15], 0.4, 4)
    eig = np.linalg.eigvalsh(cov)
    assert eig.min() > -1e-10
