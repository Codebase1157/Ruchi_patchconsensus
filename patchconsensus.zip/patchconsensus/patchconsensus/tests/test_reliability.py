"""Tests for disagreement energies, three-cornered-hat recovery, and fusion
(Eq 12-15, Proposition 2)."""
import numpy as np

from patchconsensus.noise_model import DualNoiseModel, NoiseParams
from patchconsensus import reliability as R


def _logits(params, P, n, seed):
    m = DualNoiseModel(params, P=P, rng=seed)
    return m.sample(n)["eps"][..., 0]  # (n, M, P); signal cancels in differences


def test_energy_closed_forms():
    """Eq (12): D_enc, D_pat, D_crs match their closed forms."""
    p = NoiseParams([0.3, 0.55, 0.18], [0.12, 0.07, 0.20], 0.35)
    E = R.disagreement_energies(_logits(p, 4, 400_000, 0))
    assert abs(E["D_enc"][0] - (2 * p.sigma_0 + 2 * p.sigma_a[0])) < 0.02
    assert abs(E["D_pat"][0, 1] - (p.tau[0] + p.tau[1])) < 0.02
    assert abs(E["D_crs"][0, 1] - (p.tau[0] + p.tau[1] + 2 * p.sigma_0)) < 0.02


def test_three_cornered_hat_recovers_variances():
    """Proposition 2a: M≥3, P≥2 recovers all 2M+1 variances."""
    p = NoiseParams([0.3, 0.55, 0.18], [0.12, 0.07, 0.20], 0.35)
    E = R.disagreement_energies(_logits(p, 4, 600_000, 1))
    rec = R.recover_variances(E)
    assert abs(rec["sigma_0"] - p.sigma_0) / p.sigma_0 < 0.05
    assert np.max(np.abs(rec["sigma_a"] - p.sigma_a) / p.sigma_a) < 0.1
    assert np.max(np.abs(rec["sigma_c"] - p.sigma_c) / p.sigma_c) < 0.15


def test_non_identifiable_at_P1():
    """Proposition 2c: with P=1, σ0² is not identifiable."""
    p = NoiseParams([0.3, 0.55, 0.18], [0.12, 0.07, 0.20], 0.35)
    E = R.disagreement_energies(_logits(p, 1, 50_000, 2))
    rec = R.recover_variances(E)
    assert not np.isfinite(rec["sigma_0"])


def test_corner_fallback_is_uniform():
    """ReliabilityEstimator falls back to uniform weights at P=1."""
    est = R.ReliabilityEstimator()
    logits = np.random.default_rng(0).standard_normal((9, 3, 1))
    out = est(logits)
    assert out["fallback"] is True
    assert np.allclose(out["weights"], 1 / 3)


def test_weights_sum_to_one():
    cov = R.source_covariance([0.3, 0.5, 0.2], [0.1, 0.08, 0.15], 0.4, 4)
    w = R.min_variance_weights(cov)
    assert abs(w.sum() - 1) < 1e-9
