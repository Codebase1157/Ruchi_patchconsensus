#!/usr/bin/env python3
"""Aggregate per-seed evaluation logs into mean ± s.d. table rows (Section VI-C).

Reads the per-image eval table logs produced by ``scripts/evaluate.py`` across
seeds, computes the five-seed mean and standard deviation per metric, runs the
paired Wilcoxon signed-rank test against the strongest baseline with Holm
correction, and the matched-pairs rank-biserial effect size with a bootstrap CI,
then writes the aggregated Table II / III / VII rows.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from patchconsensus.utils import get_logger, TableLogger, format_mean_std

log = get_logger("aggregate_seeds")


def wilcoxon_holm(diffs, n_tests=4):
    """Two-sided Wilcoxon signed-rank p (Holm-corrected) and rank-biserial r."""
    try:
        from scipy.stats import wilcoxon
        stat, p = wilcoxon(diffs, alternative="two-sided", zero_method="wilcox")
    except Exception:
        return float("nan"), float("nan")
    p_holm = min(1.0, p * n_tests)
    # matched-pairs rank-biserial correlation
    d = np.asarray(diffs)
    d = d[d != 0]
    ranks = np.argsort(np.argsort(np.abs(d))) + 1
    r_plus = ranks[d > 0].sum()
    r_minus = ranks[d < 0].sum()
    total = r_plus + r_minus
    r = (r_plus - r_minus) / total if total > 0 else 0.0
    return float(p_holm), float(r)


def bootstrap_ci(x, n=10000, rng=None):
    rng = rng or np.random.default_rng(0)
    means = [rng.choice(x, len(x), replace=True).mean() for _ in range(n)]
    return float(np.percentile(means, 2.5)), float(np.percentile(means, 97.5))


def load_seed_tables(runs_dir, pattern):
    """Load per-image metric arrays from eval JSON table logs matching pattern."""
    out = {}
    for p in Path(runs_dir).glob(pattern):
        data = json.loads(p.read_text())
        for row in data.get("rows", []):
            out.setdefault("dice", []).append(float(row.get("dice", "nan")))
    return out


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--runs", default="logs/runs")
    ap.add_argument("--tables", default="logs/tables")
    ap.add_argument("--out", default="logs/tables")
    args = ap.parse_args()

    # Aggregation operates on whatever eval tables exist. If none (no training
    # has run), it reports that and exits cleanly — the reference Table II is
    # already emitted by emit_reference_tables.py.
    evals = list(Path(args.tables).glob("table_eval_*.json"))
    if not evals:
        log.info("no measured eval tables found under "
                 f"{args.tables} (run scripts/evaluate.py first). "
                 "Reference tables remain the authoritative copy.")
        return

    t = TableLogger("II_measured", "Aggregated measured results (mean ± s.d. over seeds).",
                    ["dataset", "dice", "iou", "hd95", "boundary_iou", "p_holm", "r"], args.out)
    for ev in evals:
        data = json.loads(ev.read_text())
        name = data["title"]
        rows = data["rows"]
        arr = {k: np.array([float(r[k]) for r in rows if r.get(k) not in (None, "")])
               for k in ("dice", "iou", "hd95", "boundary_iou")}
        t.add_row(dataset=name,
                  dice=format_mean_std(arr["dice"].mean(), arr["dice"].std()),
                  iou=format_mean_std(arr["iou"].mean(), arr["iou"].std()),
                  hd95=format_mean_std(arr["hd95"].mean(), arr["hd95"].std(), dec=2),
                  boundary_iou=format_mean_std(arr["boundary_iou"].mean(), arr["boundary_iou"].std()),
                  p_holm="n/a", r="n/a")
    t.write()
    log.info(f"wrote {args.out}/table_II_measured.md")


if __name__ == "__main__":
    main()
