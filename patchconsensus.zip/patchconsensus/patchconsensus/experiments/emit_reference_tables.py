#!/usr/bin/env python3
"""Emit the manuscript's reported Tables I-VII as structured log files.

These are the *reference* values from the paper (CSV + JSON + Markdown per table),
written so that a full reproduction run can be diffed against them and so the
release ships a machine-readable copy of every table. They are the paper's
numbers, not freshly computed here; ``scripts/evaluate.py`` and
``experiments/aggregate_seeds.py`` produce the measured counterparts under the
same ``logs/tables/`` directory, with a ``_measured`` suffix.
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from patchconsensus.utils import TableLogger, get_logger

log = get_logger("emit_reference_tables")


def table_I(out):
    t = TableLogger("I", "Datasets and protocols (counts after deduplication) [REFERENCE]",
                    ["Dataset", "Images (train/val/test)", "Masks", "Split unit", "Role"], out)
    t.add_row(Dataset="HAM10000", **{"Images (train/val/test)": "7010 / 1001 / 2004",
              "Masks": "semi-auto.", "Split unit": "lesion", "Role": "Main benchmark"})
    t.add_row(Dataset="ISIC 2018", **{"Images (train/val/test)": "1886 / 269 / 539",
              "Masks": "manual", "Split unit": "patient", "Role": "Second benchmark"})
    t.add_row(Dataset="PH2", **{"Images (train/val/test)": "– / – / 200",
              "Masks": "manual", "Split unit": "–", "Role": "External test"})
    t.add_row(Dataset="ISIC 2024", **{"Images (train/val/test)": "– / – / 1000",
              "Masks": "ours", "Split unit": "–", "Role": "External test, 3D TBP"})
    t.add_note("HAM10000 split 70/10/20 by lesion, stratified by diagnosis.")
    return t


def table_II(out):
    cols = ["Method", "HAM_Dice", "HAM_IoU", "HAM_HD95", "ISIC18_Dice", "ISIC18_IoU", "ISIC18_HD95",
            "PH2_Dice", "PH2_IoU", "PH2_HD95", "ISIC24_Dice", "ISIC24_IoU", "ISIC24_HD95"]
    t = TableLogger("II", "Comparison with the state of the art. Mean ± s.d. over five seeds; "
                    "Dice/IoU in %, HD95 in pixels. [REFERENCE — paper values]", cols, out)
    rows = [
        ("U-Net [6]", "90.1±0.4","81.4±0.6","11.40±0.53", "86.9±0.6","76.2±0.9","16.11±1.78", "88.0±1.0","77.9±1.7","15.14±2.35", "74.8±0.6","59.1±0.6","29.99±1.16"),
        ("nnU-Net [4]", "92.0±0.3","84.6±0.6","8.20±0.94", "90.1±0.9","81.4±1.2","10.52±2.02", "91.4±1.2","83.6±1.4","9.80±1.77", "80.8±0.4","67.1±0.7","17.65±1.13"),
        ("TransUNet [8]", "91.2±0.4","83.2±0.5","9.80±1.03", "88.6±0.8","79.0±1.1","13.48±1.65", "89.8±0.8","80.9±1.0","12.64±2.30", "77.9±0.6","63.2±0.7","24.45±1.26"),
        ("VM-UNet [11]", "91.5±0.4","83.7±0.5","9.50±1.04", "89.1±0.7","79.8±0.9","12.89±1.70", "90.3±1.0","81.8±1.6","12.08±2.91", "78.8±0.4","64.4±0.6","23.05±1.35"),
        ("SCE-Net [3]", "92.2±0.3","84.9±0.7","8.60±1.18", "90.1±0.8","81.4±0.9","11.43±1.75", "91.4±0.6","83.6±1.4","10.69±2.25", "80.4±0.5","66.6±0.8","19.98±1.22"),
        ("MedSAM [15]", "90.8±0.5","82.6±0.4","10.30±0.79", "88.4±0.8","78.6±0.9","13.88±1.34", "89.6±0.8","80.5±1.2","13.00±1.54", "77.9±0.4","63.2±0.7","24.64±1.22"),
        ("SAM 3 [16]", "89.9±0.5","81.1±0.4","11.90±1.02", "87.3±0.5","76.8±0.8","15.71±1.85", "88.5±0.8","78.8±1.2","14.68±1.84", "76.5±0.5","61.3±0.6","27.24±0.91"),
        ("PanDerm + UPerNet [14]", "92.4±0.3","85.3±0.5","8.40±0.75", "90.7±0.7","82.4±1.0","10.69±1.47", "92.0±0.7","84.6±1.1","9.96±1.61", "81.7±0.5","68.4±0.5","17.80±1.34"),
        ("EoMT [17]", "91.8±0.3","84.2±0.4","9.15±0.85", "90.2±0.4","81.5±0.9","10.61±0.88", "91.6±0.7","84.0±0.8","10.65±1.21", "81.0±0.3","67.5±0.4","13.48±1.03"),
        ("EoSeg [18]", "91.8±0.4","84.3±0.3","9.04±0.57", "90.3±0.5","81.7±0.9","10.56±1.27", "91.8±0.6","84.2±0.7","10.38±1.45", "81.2±0.4","67.7±0.6","13.23±0.98"),
        ("EoMT + DVT [19]", "92.3±0.3","85.0±0.3","8.36±0.62", "90.6±0.5","82.2±0.9","10.21±1.19", "92.0±0.5","84.6±0.8","10.14±0.95", "81.4±0.3","68.0±0.5","12.93±0.71"),
        ("Output averaging", "93.2±0.3","86.6±0.3","6.46±0.49", "91.6±0.6","83.8±0.5","7.57±1.02", "93.0±0.5","86.3±0.6","7.54±1.27", "82.0±0.3","69.0±0.3","10.99±0.40"),
        ("Feature concatenation", "93.3±0.2","86.9±0.3","6.21±0.42", "91.8±0.3","84.3±0.4","7.22±0.71", "93.2±0.5","86.7±0.6","7.26±1.07", "82.4±0.3","69.5±0.3","10.38±0.53"),
        ("Metric-guided fusion [22]", "93.5±0.1","87.1±0.2","6.04±0.57", "92.0±0.3","84.6±0.5","7.06±0.85", "93.4±0.4","87.0±0.7","7.02±1.09", "82.8±0.2","70.0±0.4","10.05±0.59"),
        ("AM-RADIO + EoMT [21]", "93.0±0.2","86.3±0.2","7.31±0.38", "91.4±0.4","83.5±0.6","8.89±1.09", "92.7±0.4","85.9±0.8","8.98±0.85", "82.4±0.3","69.4±0.4","11.44±0.58"),
        ("PatchConsensus (teacher)", "94.0±0.2","88.1±0.2","5.05±0.32", "92.7±0.3","85.9±0.3","5.61±0.63", "94.2±0.4","88.4±0.5","5.57±0.77", "84.1±0.2","71.9±0.2","8.65±0.32"),
        ("PatchConsensus (student)", "93.4±0.2","86.9±0.3","6.67±0.38", "92.1±0.3","84.8±0.4","7.43±1.03", "93.6±0.4","87.4±0.4","7.33±0.91", "83.8±0.2","71.5±0.2","9.05±0.43"),
    ]
    for r in rows:
        t.add_row(**dict(zip(cols, r)))
    t.add_note("Δ vs. metric-guided fusion (best baseline): HAM +0.50 [0.38,0.63] / −0.99; "
               "ISIC18 +0.70 [0.38,1.02] / −1.45; PH2 +0.80 [0.43,1.16] / −1.45; "
               "ISIC24 +1.30 [1.12,1.48] / −1.40.")
    t.add_note("p (Holm) / r : HAM 2.3e−21 / 0.25 (Dice), 4.5e−28 / 0.33 (HD95); "
               "ISIC24 4.0e−36 / 0.46 (Dice), 1.3e−41 / 0.52 (HD95).")
    t.add_note("vs. EoSeg (best encoder-only): +2.2 Dice / −4.0 HD95 on HAM10000.")
    return t


def table_III(out):
    cols = ["Train", "Method", "HAM10000", "ISIC 2018", "PH2", "ISIC 2024"]
    t = TableLogger("III", "Cross-dataset generalization: Dice (%), mean ± s.d. over five seeds. "
                    "[REFERENCE]", cols, out)
    for r in [
        ("HAM10000","EoMT","91.8±0.3","90.2±0.4","91.6±0.7","81.0±0.3"),
        ("HAM10000","EoSeg","91.8±0.4","90.3±0.5","91.8±0.6","81.2±0.4"),
        ("HAM10000","Ours","94.0±0.2","92.7±0.3","94.2±0.4","84.1±0.2"),
        ("ISIC 2018","EoMT","91.1±0.5","90.9±0.4","91.7±0.7","81.1±0.4"),
        ("ISIC 2018","EoSeg","91.2±0.5","91.0±0.4","91.8±0.6","81.3±0.4"),
        ("ISIC 2018","Ours","93.7±0.3","93.1±0.3","94.2±0.4","84.2±0.2"),
    ]:
        t.add_row(**dict(zip(cols, r)))
    t.add_note("Trained on HAM10000, mean drop on 3 unseen sets: Ours 3.65, EoMT 4.19, EoSeg 4.09.")
    return t


def table_IV(out):
    cols = ["#", "Variant", "Dice", "HD95", "B-IoU", "ECE", "Eart"]
    t = TableLogger("IV", "Ablation on HAM10000 (mean ± s.d. over five seeds). Eart relative to "
                    "single-encoder EoMT. [REFERENCE]", cols, out)
    for r in [
        ("1","Single encoder (EoMT)","91.79±0.31","9.15±0.85","65.1±0.5","0.062","1.00"),
        ("2","Encoder-only fusion (M=3, P=1)","92.71±0.26","8.06±0.71","67.2±0.4","0.048","0.84"),
        ("3","Patch-only fusion (M=1, P=4)","92.86±0.24","7.59±0.63","72.4±0.4","0.046","0.23"),
        ("4","DACQ without dual variables","93.57±0.22","5.87±0.47","73.5±0.3","0.035","0.24"),
        ("5","DACQ + uniform fusion","93.72±0.19","5.65±0.44","74.0±0.3","0.033","0.21"),
        ("6","DACQ + diagonal reliability","93.94±0.18","5.12±0.37","74.8±0.3","0.030","0.19"),
        ("7","Full PatchConsensus","93.98±0.17","5.05±0.32","74.9±0.2","0.029","0.18"),
    ]:
        t.add_row(**dict(zip(cols, r)))
    t.add_note("Eart: EoMT+DVT 0.31, Gaussian sliding-window 0.29, metric-guided fusion 0.80, full 0.18.")
    return t


def table_V(out):
    cols = ["Factor", "Setting", "Dice", "HD95", "Eart", "Δrel", "img/s"]
    t = TableLogger("V", "Design sweeps on HAM10000 (mean over five seeds). Defaults marked *. "
                    "[REFERENCE]", cols, out)
    for r in [
        ("Encoders","DINOv3","92.86","7.59","0.23","–","46.0"),
        ("Encoders","DINOv2 + DINOv3","93.12","6.70","0.19","+0.04","23.0"),
        ("Encoders","DINOv3 + PanDerm","93.67","5.85","0.19","+0.06","23.0"),
        ("Encoders","all three*","93.98","5.05","0.18","+0.26","15.3"),
        ("Stride","S (P=1)","92.71","8.06","0.84","–","61.3"),
        ("Stride","S/2 (P=4)*","93.98","5.05","0.18","+0.26","15.3"),
        ("Stride","S/4 (P=16)","94.36","4.37","0.05","+0.27","3.8"),
        ("Depth L2","1","93.86","5.22","0.21","+0.28","15.3"),
        ("Depth L2","4*","93.98","5.05","0.18","+0.26","15.3"),
        ("Depth L2","6","93.97","5.07","0.19","+0.26","15.3"),
    ]:
        t.add_row(**dict(zip(cols, r)))
    t.add_note("Δrel = Dice gain of reliability weighting over uniform: +0.04/+0.06 at M=2, "
               "+0.26 at M=3 (matches Proposition 2).")
    return t


def table_VI(out):
    cols = ["Assumption", "Test statistic", "Measured", "Accept if"]
    t = TableLogger("VI_reference", "Tests of assumptions A1-A5 on held-out data, with 95% "
                    "bootstrap intervals. [REFERENCE — paper values]", cols, out)
    for r in [
        ("A1","mean / s.d. of residual, per encoder","0.038 [0.034, 0.043]","|·| < 0.05"),
        ("A2, content","max. corr. of cm and cm'","0.160 [0.149, 0.171]","< 0.3"),
        ("A2, position","max. corr. of am and am'","0.038 [0.034, 0.042]","< 0.3"),
        ("A3","corr. of position residuals at offset τ","0.093 [0.082, 0.104]","< 0.1"),
        ("A4","max. corr. among components and with ℓGT","0.049 [0.045, 0.053]","< 0.1"),
        ("A5","coeff. of variation of local variance","0.226 [0.211, 0.243]","< 0.25"),
    ]:
        t.add_row(**dict(zip(cols, r)))
    t.add_note("A3 holds only marginally (0.093 vs 0.1 threshold); effect bounded (Section V-D).")
    return t


def table_VII(out):
    cols = ["Metric", "EoMT", "Teacher", "Student L", "Student B"]
    t = TableLogger("VII", "Teacher-student comparison on HAM10000. One 896x896 image, batch 1, "
                    "FP32, A100 80GB. [REFERENCE]", cols, out)
    for r in [
        ("Dice (%)","91.8±0.3","94.0±0.2","93.4±0.2","92.8±0.2"),
        ("IoU (%)","84.2±0.4","88.1±0.2","86.9±0.3","86.0±0.3"),
        ("HD95 (px)","9.15±0.85","5.05±0.32","6.67±0.38","7.58±0.44"),
        ("Latency (ms)","86","742","89","31"),
        ("Peak memory (GB)","5.1","21.4","5.2","2.3"),
        ("GFLOPs","1180","7290","1184","402"),
        ("Parameters (M)","309","1048","312","94"),
    ]:
        t.add_row(**dict(zip(cols, r)))
    t.add_note("ViT-L student keeps 71% of the teacher's gain over EoMT at 8.3x the teacher's speed; "
               "ViT-B keeps 47% at 23.9x.")
    return t


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="logs/tables")
    args = ap.parse_args()
    builders = [table_I, table_II, table_III, table_IV, table_V, table_VI, table_VII]
    for b in builders:
        t = b(args.out)
        paths = t.write()
        log.info(f"wrote reference {paths['md']}")
    log.info(f"all reference tables under {args.out}/")


if __name__ == "__main__":
    main()
