#!/usr/bin/env python3
"""Numerically validate every closed-form result of Section V.

This is the heart of the *verifiable* reproduction: with no GPU, data, or model
weights, it checks that the paper's algebra is correct and that the numpy
implementation realises it. For each claim it compares a Monte-Carlo measurement
on samples from the dual noise model (Eq 3) against the closed form, and asserts
agreement within tolerance.

Checks
------
  T1a  Eq (18): measured fusion error == w^T Σ w == three-family decomposition
  T1b  Eq (19): uniform-weight error closed form
  T1c  Thm 1(c): min over unbiased weights == (1^T Σ^-1 1)^-1, attained by Eq (15)
  T1d  Thm 1(a): P=1 floor == σ0²;  M=1 floor == σc,1²
  P2   Prop 2 / Eq (12-13): three-cornered-hat recovers all 2M+1 variances
       (M≥3, P≥2); and non-identifiability at M=2 and P=1
  L1   Lemma 1 / Prop 3: consensus ADMM -> inverse-variance mean, primal residual
       -> 0, duals measure disagreement

Writes a JSON + Markdown report under --out and exits non-zero if any check fails.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from patchconsensus.noise_model import DualNoiseModel, NoiseParams
from patchconsensus import theory as T
from patchconsensus import reliability as R
from patchconsensus.dacq import ConsensusADMM, inverse_variance_mean
from patchconsensus.utils import get_logger, RunLogger

log = get_logger("validate_theory")


def _rel(a, b):
    return abs(a - b) / (abs(b) + 1e-12)


def check_theorem1(rng, n_samples=400_000):
    """T1a-d: error decomposition, uniform/min-variance forms, and floors."""
    results = []
    M, P = 3, 4
    params = NoiseParams(sigma_c=[0.30, 0.50, 0.20], sigma_a=[0.10, 0.08, 0.15], sigma_0=0.40)
    model = DualNoiseModel(params, P=P, dim=1, rng=rng)
    cov = model.covariance()

    # ---- T1a: random weights ----
    w = rng.random(M * P)
    w = w / w.sum()
    s = model.sample(n_samples)
    err = (w @ s["eps"].reshape(n_samples, M * P).T) ** 2
    measured = float(err.mean())
    quad = float(w @ cov @ w)
    decomp = T.theorem1_error(w, params.sigma_c, params.sigma_a, params.sigma_0, P)
    ok = _rel(measured, quad) < 0.02 and _rel(quad, decomp) < 1e-9
    results.append(("T1a Eq(18): measured==wᵀΣw==decomposition",
                    {"measured": measured, "quad_form": quad, "decomposition": decomp},
                    ok))

    # ---- T1b: uniform weights ----
    wu = np.full(M * P, 1.0 / (M * P))
    err_u = float((((wu @ s["eps"].reshape(n_samples, M * P).T) ** 2)).mean())
    closed_u = T.uniform_weight_error(params.sigma_c, params.sigma_a, params.sigma_0, P)
    ok = _rel(err_u, closed_u) < 0.02
    results.append(("T1b Eq(19): uniform-weight error",
                    {"measured": err_u, "closed_form": closed_u}, ok))

    # ---- T1c: minimum-variance weights ----
    w_star = R.min_variance_weights(cov)
    err_star = float((((w_star @ s["eps"].reshape(n_samples, M * P).T) ** 2)).mean())
    min_pred = T.min_variance_error(cov)
    # Optimality is checked on the EXACT quadratic form wᵀΣw (no MC noise):
    # no feasible w should give a smaller quadratic than the predicted minimum.
    quad_star = float(w_star @ cov @ w_star)
    best_random = np.inf
    for _ in range(5000):
        wr = rng.random(M * P); wr /= wr.sum()
        best_random = min(best_random, float(wr @ cov @ wr))
    ok = (_rel(quad_star, min_pred) < 1e-9            # w* attains the closed-form minimum
          and min_pred <= best_random + 1e-9           # nothing feasible beats it
          and _rel(err_star, min_pred) < 0.05          # MC measurement agrees
          and err_star < err_u)                        # and it beats uniform
    results.append(("T1c Thm1(c): min-variance == (1ᵀΣ⁻¹1)⁻¹ and is optimal",
                    {"quad_form_wstar": quad_star, "predicted_min": min_pred,
                     "measured_wstar": err_star, "uniform": err_u,
                     "best_random_quad": best_random}, bool(ok)))

    # ---- T1d: floors ----
    # P=1 (encoder-only): error >= σ0² for every weighting
    m1 = DualNoiseModel(params, P=1, rng=rng)
    cov1 = m1.covariance()
    floor_p1 = T.min_variance_error(cov1)
    ok_p1 = floor_p1 >= params.sigma_0 - 1e-6
    # M=1 (patch-only): error >= σc,1²
    p_single = NoiseParams(sigma_c=[params.sigma_c[0]], sigma_a=[params.sigma_a[0]],
                           sigma_0=params.sigma_0)
    mM1 = DualNoiseModel(p_single, P=4, rng=rng)
    floor_m1 = T.min_variance_error(mM1.covariance())
    ok_m1 = floor_m1 >= p_single.sigma_c[0] - 1e-6
    results.append(("T1d Thm1(a): P=1 floor≥σ0²,  M=1 floor≥σc,1²",
                    {"P1_min_error": floor_p1, "sigma0_sq": params.sigma_0,
                     "M1_min_error": floor_m1, "sigma_c1_sq": float(p_single.sigma_c[0])},
                    bool(ok_p1 and ok_m1)))
    return results


def check_identifiability(rng, n_samples=600_000):
    """P2: three-cornered-hat recovery (M≥3, P≥2) and non-identifiability cases."""
    results = []
    M, P = 3, 4
    params = NoiseParams(sigma_c=[0.30, 0.55, 0.18], sigma_a=[0.12, 0.07, 0.20], sigma_0=0.35)
    model = DualNoiseModel(params, P=P, rng=rng)
    s = model.sample(n_samples)
    logits = s["eps"][..., 0]  # (N, M, P) — signal cancels in all differences anyway

    energies = R.disagreement_energies(logits)
    rec = R.recover_variances(energies)
    errs = {
        "sigma_0": _rel(rec["sigma_0"], params.sigma_0),
        "sigma_a": float(np.max(np.abs(rec["sigma_a"] - params.sigma_a) / (params.sigma_a))),
        "sigma_c": float(np.max(np.abs(rec["sigma_c"] - params.sigma_c) / (params.sigma_c))),
    }
    ok = errs["sigma_0"] < 0.05 and errs["sigma_a"] < 0.08 and errs["sigma_c"] < 0.12
    results.append(("P2a M≥3,P≥2: recover σ0², σa,m², σc,m² (3-cornered hat)",
                    {"true_sigma_c": list(params.sigma_c), "rec_sigma_c": [round(float(x),4) for x in rec["sigma_c"]],
                     "true_sigma_a": list(params.sigma_a), "rec_sigma_a": [round(float(x),4) for x in rec["sigma_a"]],
                     "true_sigma_0": params.sigma_0, "rec_sigma_0": round(float(rec["sigma_0"]),4),
                     "rel_errors": {k: round(v,4) for k,v in errs.items()}}, bool(ok)))

    # Verify Eq (12) relations hold on the measured energies
    m0, m1 = 0, 1
    tau = params.tau
    exp_Denc = 2 * params.sigma_0 + 2 * params.sigma_a
    exp_Dpat01 = tau[m0] + tau[m1]
    exp_Dcrs01 = tau[m0] + tau[m1] + 2 * params.sigma_0
    ok12 = (_rel(energies["D_enc"][m0], exp_Denc[m0]) < 0.05
            and _rel(energies["D_pat"][m0, m1], exp_Dpat01) < 0.05
            and _rel(energies["D_crs"][m0, m1], exp_Dcrs01) < 0.05)
    results.append(("P2 Eq(12): D_enc, D_pat, D_crs match closed forms",
                    {"D_enc_0": {"measured": round(float(energies['D_enc'][m0]),4), "expected": round(float(exp_Denc[m0]),4)},
                     "D_pat_01": {"measured": round(float(energies['D_pat'][m0,m1]),4), "expected": round(float(exp_Dpat01),4)},
                     "D_crs_01": {"measured": round(float(energies['D_crs'][m0,m1]),4), "expected": round(float(exp_Dcrs01),4)}},
                    bool(ok12)))

    # P2c: P=1 -> σ0² not identifiable (no D_enc, no D_crs)
    m_p1 = DualNoiseModel(params, P=1, rng=rng)
    e_p1 = R.disagreement_energies(m_p1.sample(50_000)["eps"][..., 0])
    rec_p1 = R.recover_variances(e_p1)
    ok_p1 = not np.isfinite(rec_p1["sigma_0"])  # NaN -> correctly flagged unidentifiable
    results.append(("P2c P=1: σ0² flagged non-identifiable",
                    {"sigma_0_estimate": ("nan" if not np.isfinite(rec_p1["sigma_0"]) else float(rec_p1["sigma_0"]))},
                    bool(ok_p1)))

    # P2b: M=2 -> τ_m (hence σc,m²) not separable (only the sum is identified)
    p2 = NoiseParams(sigma_c=[0.30, 0.55], sigma_a=[0.12, 0.07], sigma_0=0.35)
    e_m2 = R.disagreement_energies(DualNoiseModel(p2, P=4, rng=rng).sample(200_000)["eps"][..., 0])
    rec_m2 = R.recover_variances(e_m2)
    tau_sum_identified = _rel(float(np.nansum(rec_m2["sigma_a"]) + e_m2["D_pat"][0, 1] - float(np.nansum(rec_m2["sigma_a"])),
                                   ), 1) if False else True  # placeholder; real check below
    # the sum τ1+τ2 == D_pat[0,1] must be recoverable; individual τ_m must be NaN
    sum_ok = _rel(e_m2["D_pat"][0, 1], p2.tau[0] + p2.tau[1]) < 0.05
    indiv_unid = np.all(~np.isfinite(rec_m2["tau"]))
    results.append(("P2b M=2: only τ1+τ2 identified, individual τ_m not",
                    {"tau_sum_measured": round(float(e_m2['D_pat'][0,1]),4),
                     "tau_sum_true": round(float(p2.tau[0]+p2.tau[1]),4),
                     "individual_tau_nan": bool(indiv_unid)}, bool(sum_ok and indiv_unid)))
    return results


def check_consensus(rng):
    """L1 / Prop 3: exact consensus ADMM converges to the inverse-variance mean,
    primal residual -> 0, and duals measure disagreement."""
    results = []
    n, d = 6, 4
    y = rng.standard_normal((n, d))
    sigma2 = rng.uniform(0.2, 2.0, size=n)

    # equal penalties (Prop 3 / Lemma 1 corollary). Enough iterations for the
    # linear ADMM rate to reach the fixed point regardless of conditioning.
    admm = ConsensusADMM(y, sigma2, T=1.0, adaptive_rho=False)
    out = admm.run(n_iter=600, record=True)
    z_star = inverse_variance_mean(y, sigma2)
    z_err = float(np.linalg.norm(out["z"] - z_star))
    primal_final = out["history"]["primal"][-1]
    # primal residual should decrease over the run (monotone non-increasing)
    ph = out["history"]["primal"]
    primal_decreasing = ph[-1] <= ph[5] and all(b <= a + 1e-9 for a, b in zip(ph[5:], ph[6:]))
    ok = z_err < 1e-4 and primal_final < 1e-4 and primal_decreasing
    results.append(("L1/Prop3: z -> inverse-variance mean; primal residual -> 0",
                    {"||z - z*||": z_err, "primal_final": float(primal_final),
                     "primal_decreasing": bool(primal_decreasing)}, bool(ok)))

    # duals measure disagreement: a far-off source accumulates a larger ||u||
    y2 = y.copy()
    y2[0] += 10.0  # make source 0 an outlier
    out2 = ConsensusADMM(y2, sigma2, T=1.0, adaptive_rho=False).run(n_iter=200)
    unorms = np.linalg.norm(out2["u"], axis=1)
    ok2 = int(np.argmax(unorms)) == 0
    results.append(("L1: dual norm ||u_i|| largest for the most disagreeing source",
                    {"argmax_u": int(np.argmax(unorms)), "u_norms": [round(float(x),3) for x in unorms]},
                    bool(ok2)))

    # adaptive rho (Eq 10) down-weights the outlier
    out3 = ConsensusADMM(y2, sigma2, T=1.0, adaptive_rho=True, freeze_after=2).run(n_iter=50)
    ok3 = int(np.argmin(out3["rho"])) == 0
    results.append(("Eq(10): reliability ρ_i smallest for the outlier source",
                    {"argmin_rho": int(np.argmin(out3["rho"])), "rho": [round(float(x),4) for x in out3["rho"]]},
                    bool(ok3)))
    return results


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--seeds", type=int, default=5, help="repeat each check over this many seeds")
    ap.add_argument("--out", default="logs/validation")
    args = ap.parse_args()
    Path(args.out).mkdir(parents=True, exist_ok=True)

    all_results = []
    with RunLogger("validate_theory", log_dir=args.out) as rlog:
        for seed in range(args.seeds):
            rng = np.random.default_rng(1000 + seed)
            batch = []
            batch += check_theorem1(rng)
            batch += check_identifiability(rng)
            batch += check_consensus(rng)
            for name, detail, ok in batch:
                rlog.log("check", seed=seed, name=name, passed=bool(ok))
                all_results.append({"seed": seed, "name": name, "passed": bool(ok), "detail": detail})

    # aggregate pass-rate per check
    from collections import defaultdict
    agg = defaultdict(list)
    for r in all_results:
        agg[r["name"]].append(r["passed"])
    summary = {name: {"pass_rate": sum(v) / len(v), "n": len(v)} for name, v in agg.items()}
    n_fail = sum(1 for v in summary.values() if v["pass_rate"] < 1.0)

    # write report
    report = {"n_seeds": args.seeds, "summary": summary, "results": all_results}
    (Path(args.out) / "theory_validation.json").write_text(json.dumps(report, indent=2))
    md = ["# Theory validation report", "",
          f"Seeds: {args.seeds}. Each check runs on independent Monte-Carlo draws.", "",
          "| Check | Pass rate |", "| --- | --- |"]
    for name, v in summary.items():
        md.append(f"| {name} | {int(v['pass_rate']*v['n'])}/{v['n']} |")
    md.append("")
    md.append(f"**{len(summary)-n_fail}/{len(summary)} checks passed on every seed.**")
    (Path(args.out) / "theory_validation.md").write_text("\n".join(md))

    log.info(f"{len(summary)-n_fail}/{len(summary)} checks passed on every seed")
    log.info(f"report: {Path(args.out)/'theory_validation.md'}")
    sys.exit(1 if n_fail else 0)


if __name__ == "__main__":
    main()
