#!/usr/bin/env python3
"""Distil a one-pass student from a trained teacher (Section IV-F, Eq 17, Table VII).

Usage
-----
    python scripts/distill_student.py --config configs/student_vitl.yaml [--stub]

The student is a single encoder reading the whole image once; it is trained on
the segmentation loss plus KL to the teacher's lesion probabilities and an MSE to
the teacher's fused, low-noise features (Eq 17).
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from patchconsensus.utils import load_config, seed_everything, RunLogger, save_checkpoint, get_logger


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", required=True)
    ap.add_argument("--seed", type=int, default=None)
    ap.add_argument("--stub", action="store_true")
    ap.add_argument("--max-iters", type=int, default=None)
    args = ap.parse_args()

    cfg = load_config(args.config)
    seed = args.seed if args.seed is not None else cfg["seed"]
    seed_everything(seed)
    if args.stub:
        cfg["model"]["stub"] = True
        cfg.setdefault("student", {})["stub"] = True
        cfg["device"] = "cpu"
    log = get_logger("distill_student")

    try:
        import torch
        from torch.utils.data import DataLoader
        from patchconsensus.model import PatchConsensus, PatchConsensusConfig
        from patchconsensus.student import PatchConsensusStudent, StudentConfig
        from patchconsensus.losses import DistillationLoss
        from patchconsensus.data.datasets import LesionDataset
        from patchconsensus.utils import load_checkpoint
    except Exception as e:
        log.error(f"Distillation requires the full torch stack: {e}")
        sys.exit(1)

    device = cfg["device"]
    # teacher (frozen)
    tcfg = PatchConsensusConfig(
        encoders=tuple(cfg["model"]["encoders"]), d_shared=cfg["model"]["d_shared"],
        Q=cfg["model"]["Q"], L2=cfg["model"]["L2"], image_size=cfg["image_size"],
        patch_side=cfg["patch_side"], stride=cfg["stride"], stub=cfg["model"].get("stub", False),
    )
    teacher = PatchConsensus(tcfg).to(device).eval()
    if not args.stub and cfg.get("teacher_ckpt") and Path(cfg["teacher_ckpt"]).exists():
        teacher.load_state_dict(load_checkpoint(cfg["teacher_ckpt"]), strict=False)
        log.info(f"loaded teacher from {cfg['teacher_ckpt']}")
    for p in teacher.parameters():
        p.requires_grad_(False)

    scfg = StudentConfig(
        backbone=cfg["student"]["backbone"], size=cfg["student"]["size"],
        d_shared=cfg["model"]["d_shared"], Q=cfg["model"]["Q"], L2=cfg["model"]["L2"],
        image_size=cfg["image_size"], stub=cfg.get("student", {}).get("stub", False),
    )
    student = PatchConsensusStudent(scfg).to(device)
    criterion = DistillationLoss(lambda_d=cfg["distill"]["lambda_d"], gamma=cfg["distill"]["gamma"])
    opt = torch.optim.AdamW(student.parameters(), lr=cfg["optim"]["lr_new_modules"],
                            weight_decay=cfg["optim"]["weight_decay"])
    total_iters = args.max_iters or cfg["optim"]["iterations"]
    run_name = cfg.get("run_name", "student") + f"_seed{seed}"

    ds = LesionDataset(cfg, "train", augment=True)
    dl = DataLoader(ds, batch_size=1, shuffle=True, num_workers=4, drop_last=True)

    with RunLogger(run_name, log_dir=cfg["log"]["run_dir"]) as rlog:
        rlog.log("config", seed=seed, student=cfg["student"], iters=total_iters)
        it = 0
        while it < total_iters:
            for batch in dl:
                img = batch["image"][0].to(device)
                tgt = batch["mask"].to(device)
                with torch.no_grad():
                    tout = teacher(img, tgt_mask=tgt)
                    t_prob = tout["fused_mask"].max(1).values.sigmoid()
                    t_feat = tout["z"].mean(0, keepdim=True).expand(1, scfg.d_shared)
                sout = student(img.unsqueeze(0))
                teacher_d = {"prob": t_prob, "feat": t_feat.expand_as(sout["feat"].mean(1))
                             if sout["feat"].dim() == 3 else t_feat}
                # align feature shapes for the MSE term
                sfeat = sout["feat"].mean(1)
                losses = criterion(
                    {"mask": sout["mask"], "cls": sout["cls"], "prob": sout["prob"], "feat": sfeat},
                    {"prob": t_prob, "feat": t_feat.expand_as(sfeat)},
                    tgt,
                )
                opt.zero_grad(); losses["total"].backward(); opt.step()
                it += 1
                if it % 50 == 0:
                    rlog.log("train", iter=it, loss=float(losses["total"]),
                             kl=float(losses["kl"]), feat=float(losses["feat"]))
                if it >= total_iters:
                    break
        p = save_checkpoint(student.state_dict(), f"{cfg['log']['ckpt_dir']}/{run_name}.pth",
                            meta={"seed": seed, "config": args.config})
        rlog.log("checkpoint", path=p)
    log.info("done.")


if __name__ == "__main__":
    main()
