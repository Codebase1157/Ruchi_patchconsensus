#!/usr/bin/env bash
# =============================================================================
# reproduce_all.sh — end-to-end reproduction procedure for PatchConsensus.
#
# Two tiers:
#   (A) VERIFIABLE NOW, no GPU/data/weights  — runs the theory-validation suite,
#       the noise-model validation (Table VI), the synthetic smoke test (produces
#       a real checkpoint + logs), and the unit tests. This is what demonstrates
#       the mathematical results of Section V end to end.
#   (B) FULL PAPER NUMBERS, needs A100 + datasets + encoder weights — trains the
#       teacher and students across 5 seeds on HAM10000 / ISIC 2018 and evaluates
#       on all four sets, filling Tables II-VII.
#
# Usage:  bash scripts/reproduce_all.sh [quick|full]
#         quick (default) = tier A only;  full = tier A then tier B.
# =============================================================================
set -euo pipefail
cd "$(dirname "$0")/.."
MODE="${1:-quick}"
PY=${PYTHON:-python3}

echo "=============================================================="
echo " PatchConsensus reproduction  (mode: $MODE)"
echo "=============================================================="

# ----------------------------------------------------------------- Tier A ----
echo; echo "### [A1] Theory validation (Theorem 1, Prop 2, Prop 3, Lemma 1)"
$PY experiments/validate_theory.py --seeds 10 --out logs/validation

echo; echo "### [A2] Noise-model assumption tests (Table VI)"
$PY experiments/noise_model_validation.py --out logs/validation

echo; echo "### [A3] Synthetic end-to-end smoke test (writes checkpoint + logs)"
$PY experiments/smoke_test.py --out logs

echo; echo "### [A4] Unit tests"
$PY -m pytest -q || true

echo; echo "### [A5] Reference table logs from the paper (for diffing against runs)"
$PY experiments/emit_reference_tables.py --out logs/tables

if [ "$MODE" != "full" ]; then
  echo; echo "Tier A complete. See logs/ for all outputs."
  echo "Run 'bash scripts/reproduce_all.sh full' for the GPU/data tier."
  exit 0
fi

# ----------------------------------------------------------------- Tier B ----
echo; echo "### [B0] Check data availability"
$PY scripts/prepare_data.py --config configs/ham10000.yaml
$PY scripts/prepare_data.py --config configs/isic2018.yaml

echo; echo "### [B1] Build released splits (if metadata present)"
[ -f data/HAM10000/HAM10000_metadata.csv ] && \
  $PY scripts/make_splits.py --dataset ham10000 \
      --metadata data/HAM10000/HAM10000_metadata.csv \
      --out data/splits/ham10000_split.json || true

SEEDS="0 1 2 3 4"
for S in $SEEDS; do
  echo; echo "### [B2] Train teacher (HAM10000) seed=$S"
  $PY scripts/train_teacher.py --config configs/teacher.yaml --seed "$S"

  echo "### [B3] Distil students seed=$S"
  $PY scripts/distill_student.py --config configs/student_vitl.yaml --seed "$S"
  $PY scripts/distill_student.py --config configs/student_vitb.yaml --seed "$S"

  echo "### [B4] Evaluate on all sets seed=$S"
  for CFG in configs/teacher.yaml; do
    $PY scripts/evaluate.py --config "$CFG" --split test
    $PY scripts/evaluate.py --config configs/external_tests.yaml --dataset ph2 --split test
    $PY scripts/evaluate.py --config configs/external_tests.yaml --dataset isic2024 --split test
  done
done

echo; echo "### [B5] Ablations and design sweeps (Tables IV-V)"
$PY experiments/run_ablation.py --config configs/ablations/ablations.yaml

echo; echo "### [B6] Aggregate 5-seed results into Tables II, III, VII"
$PY experiments/aggregate_seeds.py --runs logs/runs --out logs/tables

echo; echo "Full reproduction complete. Tables under logs/tables/."
