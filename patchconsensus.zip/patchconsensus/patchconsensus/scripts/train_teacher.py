#!/usr/bin/env python3
"""Train the PatchConsensus teacher (Section IV-F, Table II).

Usage
-----
    python scripts/train_teacher.py --config configs/teacher.yaml [--seed 0] [--stub]

``--stub`` swaps the real foundation encoders for tiny ViTs so the whole loop
runs on CPU without the multi-GB checkpoints (useful for a dry run / CI). Real
training needs torch + the encoder weights (see docs/REPRODUCE.md) and an A100.

Writes a JSONL run log, periodic eval rows, and best/last checkpoints under the
paths in the config's ``log`` block.
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from patchconsensus.utils import load_config, seed_everything, RunLogger, save_checkpoint, get_logger


def build_optimizer(model, cfg):
    import torch
    new_params, adapter_params = [], []
    for n, p in model.named_parameters():
        if not p.requires_grad:
            continue
        (adapter_params if ("A" == n.split(".")[-1] or "B" == n.split(".")[-1]
                            or "lora" in n.lower()) else new_params).append(p)
    o = cfg["optim"]
    return torch.optim.AdamW(
        [{"params": new_params, "lr": o["lr_new_modules"]},
         {"params": adapter_params, "lr": o["lr_adapters"]}],
        weight_decay=o["weight_decay"], betas=tuple(o["betas"]),
    )


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", required=True)
    ap.add_argument("--seed", type=int, default=None)
    ap.add_argument("--stub", action="store_true", help="tiny encoders, CPU dry run")
    ap.add_argument("--max-iters", type=int, default=None, help="override for a quick run")
    args = ap.parse_args()

    cfg = load_config(args.config)
    seed = args.seed if args.seed is not None else cfg["seed"]
    seed_everything(seed)
    if args.stub:
        cfg["model"]["stub"] = True
        cfg["device"] = "cpu"
    log = get_logger("train_teacher")

    try:
        import torch
        from torch.utils.data import DataLoader
        from patchconsensus.model import PatchConsensus, PatchConsensusConfig
        from patchconsensus.losses import TeacherLoss
        from patchconsensus.data.datasets import LesionDataset
    except Exception as e:
        log.error(f"Training requires the full torch stack: {e}")
        log.error("Install with: pip install -e '.[train]'  (see docs/REPRODUCE.md)")
        sys.exit(1)

    mcfg = PatchConsensusConfig(
        encoders=tuple(cfg["model"]["encoders"]), d_shared=cfg["model"]["d_shared"],
        Q=cfg["model"]["Q"], L2=cfg["model"]["L2"], lora_rank=cfg["model"]["lora_rank"],
        image_size=cfg["image_size"], patch_side=cfg["patch_side"], stride=cfg["stride"],
        temperature=cfg["model"]["temperature"], freeze_rho_after=cfg["model"]["freeze_rho_after"],
        stub=cfg["model"].get("stub", False),
    )
    device = cfg["device"]
    model = PatchConsensus(mcfg).to(device)
    criterion = TeacherLoss(beta=cfg["loss"]["beta"], lambda_c=cfg["loss"]["lambda_c"])
    opt = build_optimizer(model, cfg)
    total_iters = args.max_iters or cfg["optim"]["iterations"]
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=total_iters)

    run_name = cfg.get("run_name", "teacher") + f"_seed{seed}"
    ckpt_dir = cfg["log"]["ckpt_dir"]
    log.info(f"params: trainable={model.trainable_parameters():,} total={model.total_parameters():,}")

    ds = LesionDataset(cfg, "train", augment=True)
    dl = DataLoader(ds, batch_size=1, shuffle=True, num_workers=4, drop_last=True)

    best = -1.0
    with RunLogger(run_name, log_dir=cfg["log"]["run_dir"]) as rlog:
        rlog.log("config", seed=seed, iters=total_iters, encoders=cfg["model"]["encoders"])
        it = 0
        model.train()
        while it < total_iters:
            for batch in dl:
                img = batch["image"][0].to(device)
                tgt = batch["mask"].to(device)
                out = model(img, tgt_mask=tgt)
                losses = criterion(out)
                opt.zero_grad()
                losses["total"].backward()
                torch.nn.utils.clip_grad_norm_(model.parameters(), cfg["optim"]["grad_clip"])
                opt.step(); sched.step()
                it += 1
                if it % 50 == 0:
                    rlog.log("train", iter=it, loss=float(losses["total"]),
                             L_fus=float(losses["L_fus"]), L_con=float(losses["L_con"]),
                             lr=sched.get_last_lr()[0])
                if it % cfg["log"]["save_every"] == 0 or it >= total_iters:
                    p = save_checkpoint(
                        {k: v for k, v in model.state_dict().items()},
                        f"{ckpt_dir}/{run_name}_iter{it}.pth",
                        meta={"iter": it, "seed": seed, "config": args.config},
                    )
                    rlog.log("checkpoint", path=p, iter=it)
                if it >= total_iters:
                    break
    log.info("done.")


if __name__ == "__main__":
    main()
