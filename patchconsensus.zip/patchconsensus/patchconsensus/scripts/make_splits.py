#!/usr/bin/env python3
"""Generate the released split files (Section VI-A).

HAM10000: 70/10/20 by lesion id, stratified by diagnosis, read from the official
``HAM10000_metadata.csv`` (columns ``image_id``, ``lesion_id``, ``dx``).
ISIC 2018: by patient where metadata allow, else by image.

Usage
-----
    python scripts/make_splits.py --dataset ham10000 \
        --metadata data/HAM10000/HAM10000_metadata.csv \
        --out data/splits/ham10000_split.json
"""
from __future__ import annotations

import argparse
import csv
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from patchconsensus.data.splits import make_lesion_split, make_patient_split, save_split


def read_ham_metadata(path):
    with open(path, newline="") as f:
        for row in csv.DictReader(f):
            yield (row["image_id"], row.get("lesion_id", row["image_id"]), row.get("dx", "unk"))


def read_isic_metadata(path):
    with open(path, newline="") as f:
        for row in csv.DictReader(f):
            iid = row.get("image") or row.get("image_id") or row.get("isic_id")
            yield (iid, row.get("patient_id", iid), None)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--dataset", required=True, choices=["ham10000", "isic2018"])
    ap.add_argument("--metadata", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--seed", type=int, default=0)
    args = ap.parse_args()

    if args.dataset == "ham10000":
        items = list(read_ham_metadata(args.metadata))
        split = make_lesion_split(items, ratios=(0.70, 0.10, 0.20), seed=args.seed)
        meta = {"dataset": "HAM10000", "unit": "lesion", "stratified": "diagnosis",
                "ratios": [0.7, 0.1, 0.2], "seed": args.seed}
    else:
        items = list(read_isic_metadata(args.metadata))
        split = make_patient_split(items, ratios=(0.70, 0.10, 0.20), seed=args.seed)
        meta = {"dataset": "ISIC2018", "unit": "patient", "ratios": [0.7, 0.1, 0.2], "seed": args.seed}

    save_split(split, args.out, meta=meta)
    print(f"wrote {args.out}: " + ", ".join(f"{k}={len(v)}" for k, v in split.items()))


if __name__ == "__main__":
    main()
