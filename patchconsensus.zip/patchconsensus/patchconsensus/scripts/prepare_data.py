#!/usr/bin/env python3
"""Verify dataset layout and report what is present (Section VI-A).

This does NOT download anything (datasets are under their own data-use
agreements). It checks that the expected directories exist, counts
image/mask pairs, validates split files, and prints a readiness table so a
reproduction run fails early and informatively rather than mid-training.

Usage
-----
    python scripts/prepare_data.py --config configs/ham10000.yaml
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from patchconsensus.utils import load_config, get_logger

IMG_EXT = (".png", ".jpg", ".jpeg", ".bmp", ".tif", ".tiff")


def count_images(d: Path) -> int:
    if not d.exists():
        return -1
    return sum(1 for p in d.iterdir() if p.suffix.lower() in IMG_EXT)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", required=True)
    args = ap.parse_args()
    cfg = load_config(args.config)
    log = get_logger("prepare_data")

    d = cfg["dataset"]
    images = Path(d["images"])
    masks = Path(d["masks"]) if d.get("masks") else None
    split = Path(d["split_file"]) if d.get("split_file") else None

    log.info(f"dataset        : {d['name']}")
    log.info(f"images dir     : {images}  ({count_images(images)} images)")
    if masks:
        log.info(f"masks dir      : {masks}  ({count_images(masks)} masks)")
    if split:
        ok = split.exists()
        log.info(f"split file     : {split}  ({'OK' if ok else 'MISSING — run scripts/make_splits.py'})")
        if ok:
            import json
            payload = json.loads(split.read_text())
            log.info("split counts   : " + ", ".join(f"{k}={v}" for k, v in payload["counts"].items()))
    if "counts" in d:
        log.info("expected counts: " + ", ".join(f"{k}={v}" for k, v in d["counts"].items()))

    ready = images.exists() and (masks is None or masks.exists())
    log.info("READY" if ready else "NOT READY — see docs/REPRODUCE.md for how to obtain the data")
    sys.exit(0 if ready else 2)


if __name__ == "__main__":
    main()
