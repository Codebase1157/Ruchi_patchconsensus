#!/usr/bin/env python3
"""Evaluate a trained model on a benchmark or external test set.

Usage
-----
    python scripts/evaluate.py --config configs/teacher.yaml \
        --ckpt logs/checkpoints/....pth --split test [--dataset ph2] [--stub]

Computes Dice, IoU, HD95, Boundary IoU and ECE per image, writes a per-image
CSV and a summary (mean +/- s.d.) row into the appropriate table log. The
five-seed mean +/- s.d. of Table II is produced by running this across seeds and
aggregating with ``experiments/aggregate_seeds.py``.
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from patchconsensus.utils import load_config, seed_everything, get_logger, TableLogger
from patchconsensus import metrics as M


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", required=True)
    ap.add_argument("--ckpt", default=None)
    ap.add_argument("--split", default="test")
    ap.add_argument("--dataset", default=None, help="override dataset (e.g. ph2, isic2024)")
    ap.add_argument("--stub", action="store_true")
    ap.add_argument("--limit", type=int, default=None)
    args = ap.parse_args()

    cfg = load_config(args.config)
    seed_everything(cfg["seed"])
    log = get_logger("evaluate")
    if args.stub:
        cfg["model"]["stub"] = True
        cfg["device"] = "cpu"

    try:
        import torch
        from torch.utils.data import DataLoader
        from patchconsensus.model import PatchConsensus, PatchConsensusConfig
        from patchconsensus.data.datasets import LesionDataset
        from patchconsensus.utils import load_checkpoint
    except Exception as e:
        log.error(f"Evaluation requires the full torch stack: {e}")
        sys.exit(1)

    mcfg = PatchConsensusConfig(
        encoders=tuple(cfg["model"]["encoders"]), image_size=cfg["image_size"],
        patch_side=cfg["patch_side"], stride=cfg["stride"], stub=cfg["model"].get("stub", False),
    )
    model = PatchConsensus(mcfg).to(cfg["device"]).eval()
    if args.ckpt and Path(args.ckpt).exists():
        model.load_state_dict(load_checkpoint(args.ckpt), strict=False)
        log.info(f"loaded {args.ckpt}")

    ds = LesionDataset(cfg, args.split, augment=False)
    rows = []
    with torch.no_grad():
        for i in range(len(ds) if args.limit is None else min(args.limit, len(ds))):
            b = ds[i]
            out = model(b["image"].to(cfg["device"]))
            prob = out["fused_mask"].max(1).values.sigmoid().cpu().numpy()[0]
            pred = (prob >= 0.5).astype(np.uint8)
            gt = b["mask"].numpy()
            m = M.all_metrics(pred, gt, probs=prob)
            m["id"] = b["id"]
            rows.append(m)

    name = args.dataset or cfg["dataset"]["name"]
    arr = {k: np.array([r[k] for r in rows]) for k in ("dice", "iou", "hd95", "boundary_iou", "ece")}
    summary = {k: (float(v.mean()), float(v.std())) for k, v in arr.items()}
    log.info("  ".join(f"{k}={v[0]:.2f}±{v[1]:.2f}" for k, v in summary.items()))

    tl = TableLogger("eval_" + name, f"Per-image eval on {name}/{args.split}",
                     columns=["id", "dice", "iou", "hd95", "boundary_iou", "ece"],
                     out_dir=cfg["log"]["table_dir"])
    for r in rows:
        tl.add_row(**{k: (f"{r[k]:.3f}" if isinstance(r[k], float) else r[k])
                      for k in tl.columns})
    tl.add_note("Summary: " + ", ".join(f"{k} {v[0]:.2f}±{v[1]:.2f}" for k, v in summary.items()))
    paths = tl.write()
    log.info(f"wrote {paths['md']}")


if __name__ == "__main__":
    main()
