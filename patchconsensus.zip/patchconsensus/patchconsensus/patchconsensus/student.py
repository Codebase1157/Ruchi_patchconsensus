"""One-pass distilled student (Section IV-F, Eq 17). Requires torch.

The student is a single encoder that reads the whole 896x896 image once (no
patching, no consensus), trained to reproduce the fused teacher's low-noise
features and lesion probabilities. Two sizes are provided (ViT-L, ViT-B),
matching Table VII.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F

from .encoders import build_encoder

__all__ = ["StudentConfig", "PatchConsensusStudent"]


@dataclass
class StudentConfig:
    backbone: str = "dinov3"       # single encoder
    size: str = "L"                # "L" or "B"
    d_shared: int = 256
    Q: int = 8
    L2: int = 4
    lora_rank: int = 16
    image_size: int = 896
    stub: bool = False


class PatchConsensusStudent(nn.Module):
    def __init__(self, cfg: StudentConfig):
        super().__init__()
        self.cfg = cfg
        self.encoder = build_encoder(cfg.backbone, L2=cfg.L2, lora_rank=cfg.lora_rank, stub=cfg.stub)
        self.queries = nn.Parameter(torch.randn(cfg.Q, self.encoder.dim) * 0.02)
        self.proj = nn.Linear(self.encoder.dim, cfg.d_shared)
        self.phi = nn.Sequential(
            nn.Linear(cfg.d_shared, cfg.d_shared), nn.GELU(), nn.Linear(cfg.d_shared, cfg.d_shared),
        )
        self.cls_head = nn.Linear(cfg.d_shared, 2)

    def forward(self, image: torch.Tensor) -> Dict:
        """``image``: (B, 3, H, W). One pass, whole image."""
        B = image.shape[0]
        tok = self.encoder.tokenize(image)
        tok = self.encoder.run_first_blocks(tok)
        q = self.queries.unsqueeze(0).expand(B, -1, -1)
        seq = torch.cat([tok, q], dim=1)
        for b in range(self.cfg.L2):
            seq = self.encoder.run_last_block(b, seq)
        N = tok.shape[1]
        feat = self.proj(seq[:, :N])                    # (B, N, d) low-noise feature h_st
        qz = self.proj(seq[:, N:])                      # (B, Q, d)
        logit = torch.einsum("bqd,bnd->bqn", qz, self.phi(feat))
        gm = int(round(N ** 0.5))
        logit = logit.view(B, self.cfg.Q, gm, gm)
        logit = F.interpolate(logit, size=(self.cfg.image_size, self.cfg.image_size),
                              mode="bilinear", align_corners=False)
        return {
            "mask": logit,
            "cls": self.cls_head(qz.mean(1)).unsqueeze(1).expand(B, self.cfg.Q, 2),
            "prob": logit.max(1).values.sigmoid(),
            "feat": feat,
        }

    def n_params(self) -> int:
        return sum(p.numel() for p in self.parameters())
