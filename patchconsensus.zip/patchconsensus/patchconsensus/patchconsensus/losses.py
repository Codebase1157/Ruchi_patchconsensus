"""Training objectives (Section IV-F, Eq 16-17). Requires torch.

Fused/per-source loss (Eq 16):
    L = L_fus + beta * sum_i L_i + lambda_c * sum_i || q_i - z ||_F^2
where L_fus and L_i are the EoMT loss (Hungarian matching, BCE + Dice on masks,
CE on lesion / no-object classes) [17, 34], and the last term is the
augmented-Lagrangian consensus penalty (so training lowers the same quantity the
unrolled iterations lower).

Distillation (Eq 17):
    L_st = L_seg(ell_st, Y) + lambda_d * KL(p || p_st) + gamma * || h - h_st ||_2^2
asking the student to copy the fused, low-noise teacher features.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F

try:
    from scipy.optimize import linear_sum_assignment
except Exception:  # pragma: no cover
    linear_sum_assignment = None

__all__ = ["EoMTLoss", "consensus_penalty", "TeacherLoss", "DistillationLoss"]


def dice_loss(logits: torch.Tensor, targets: torch.Tensor, eps: float = 1.0) -> torch.Tensor:
    p = logits.sigmoid().flatten(1)
    t = targets.flatten(1).float()
    num = 2 * (p * t).sum(1) + eps
    den = p.sum(1) + t.sum(1) + eps
    return (1 - num / den).mean()


class EoMTLoss(nn.Module):
    """EoMT / Mask2Former-style set-prediction loss with Hungarian matching.

    For binary lesion segmentation there is one foreground class plus a
    no-object class; queries are matched to {lesion, no-object} targets by the
    cost of CE(class) + BCE(mask) + Dice(mask), and the loss is summed over the
    matched pairs [17, 34].
    """

    def __init__(self, w_ce: float = 2.0, w_bce: float = 5.0, w_dice: float = 5.0,
                 no_object_weight: float = 0.1):
        super().__init__()
        self.w_ce, self.w_bce, self.w_dice = w_ce, w_bce, w_dice
        self.register_buffer("cls_w", torch.tensor([1.0, no_object_weight]))

    @torch.no_grad()
    def _match(self, mask_logits, cls_logits, tgt_mask):
        """Return (query_idx,) matched to the single lesion target per image."""
        B, Q = cls_logits.shape[:2]
        idx = []
        for b in range(B):
            cost_cls = -cls_logits[b].softmax(-1)[:, 0]              # (Q,)
            mb = mask_logits[b].flatten(1)                          # (Q, HW)
            tb = tgt_mask[b].flatten().float()                      # (HW,)
            p = mb.sigmoid()
            cost_bce = F.binary_cross_entropy_with_logits(
                mb, tb.expand_as(mb), reduction="none").mean(1)
            num = 2 * (p * tb).sum(1) + 1
            den = p.sum(1) + tb.sum() + 1
            cost_dice = 1 - num / den
            cost = (self.w_ce * cost_cls + self.w_bce * cost_bce + self.w_dice * cost_dice)
            if linear_sum_assignment is not None:
                r, c = linear_sum_assignment(cost[:, None].cpu().numpy())
                idx.append(int(r[0]))
            else:
                idx.append(int(cost.argmin()))
        return idx

    def forward(self, mask_logits: torch.Tensor, cls_logits: torch.Tensor,
                tgt_mask: torch.Tensor) -> torch.Tensor:
        """``mask_logits``: (B, Q, H, W); ``cls_logits``: (B, Q, 2);
        ``tgt_mask``: (B, H, W) in {0,1}."""
        B, Q = cls_logits.shape[:2]
        m_idx = self._match(mask_logits, cls_logits, tgt_mask)
        total = mask_logits.new_zeros(())
        for b in range(B):
            q = m_idx[b]
            ml = mask_logits[b, q]
            total = total + self.w_bce * F.binary_cross_entropy_with_logits(ml, tgt_mask[b].float())
            total = total + self.w_dice * dice_loss(ml[None], tgt_mask[b][None])
            # class CE: matched query -> lesion (0), others -> no-object (1)
            tgt_cls = torch.ones(Q, dtype=torch.long, device=ml.device)
            tgt_cls[q] = 0
            total = total + self.w_ce * F.cross_entropy(cls_logits[b], tgt_cls, weight=self.cls_w)
        return total / B


def consensus_penalty(q: List[torch.Tensor], z: torch.Tensor) -> torch.Tensor:
    """sum_i || q_i - z ||_F^2 — augmented-Lagrangian term of Eq (16)."""
    return sum(((qi - z) ** 2).sum() for qi in q)


@dataclass
class TeacherLoss:
    """Full teacher objective of Eq (16)."""

    beta: float = 0.5
    lambda_c: float = 0.1
    eomt: Optional[EoMTLoss] = None

    def __post_init__(self):
        self.eomt = self.eomt or EoMTLoss()

    def __call__(self, outputs: Dict) -> Dict[str, torch.Tensor]:
        """``outputs`` must provide:
          fused_mask, fused_cls, tgt_mask,
          src_masks[list], src_cls[list], q[list], z."""
        L_fus = self.eomt(outputs["fused_mask"], outputs["fused_cls"], outputs["tgt_mask"])
        L_src = sum(self.eomt(m, c, outputs["tgt_mask"])
                    for m, c in zip(outputs["src_masks"], outputs["src_cls"]))
        L_con = consensus_penalty(outputs["q"], outputs["z"])
        total = L_fus + self.beta * L_src + self.lambda_c * L_con
        return {"total": total, "L_fus": L_fus, "L_src": L_src, "L_con": L_con}


@dataclass
class DistillationLoss:
    """Student objective of Eq (17)."""

    lambda_d: float = 1.0
    gamma: float = 0.5
    eomt: Optional[EoMTLoss] = None

    def __post_init__(self):
        self.eomt = self.eomt or EoMTLoss()

    def __call__(self, student: Dict, teacher: Dict, tgt_mask: torch.Tensor) -> Dict[str, torch.Tensor]:
        L_seg = self.eomt(student["mask"], student["cls"], tgt_mask)
        p = teacher["prob"].clamp(1e-6, 1 - 1e-6)
        pst = student["prob"].clamp(1e-6, 1 - 1e-6)
        kl = (p * (p / pst).log() + (1 - p) * ((1 - p) / (1 - pst)).log()).mean()
        feat = F.mse_loss(student["feat"], teacher["feat"])
        total = L_seg + self.lambda_d * kl + self.gamma * feat
        return {"total": total, "L_seg": L_seg, "kl": kl, "feat": feat}
