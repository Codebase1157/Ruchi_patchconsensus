"""Evaluation metrics (Section VI-C).

Accuracy    : Dice, IoU, HD95 (pixels @ 896x896), Boundary IoU [47]
Calibration : Expected Calibration Error (ECE) [48]
Noise       : E_art, the feature-artifact spectral energy at the token frequency,
              reported relative to single-encoder EoMT.

All functions are pure numpy/scipy (CPU) so they run and are unit-tested here.
HD95 and Boundary IoU use ``scipy.ndimage`` distance transforms.
"""
from __future__ import annotations

from typing import Optional

import numpy as np
from scipy import ndimage

__all__ = ["dice", "iou", "hd95", "boundary_iou", "ece", "artifact_energy", "all_metrics"]


def _binarize(a: np.ndarray, thr: float = 0.5) -> np.ndarray:
    return (np.asarray(a) >= thr).astype(np.uint8)


def dice(pred: np.ndarray, gt: np.ndarray, eps: float = 1e-7) -> float:
    """Sorensen-Dice coefficient in [0, 1]."""
    p, g = _binarize(pred), _binarize(gt)
    inter = float((p & g).sum())
    return (2 * inter + eps) / (p.sum() + g.sum() + eps)


def iou(pred: np.ndarray, gt: np.ndarray, eps: float = 1e-7) -> float:
    """Intersection-over-Union (Jaccard) in [0, 1]."""
    p, g = _binarize(pred), _binarize(gt)
    inter = float((p & g).sum())
    union = float((p | g).sum())
    return (inter + eps) / (union + eps)


def _surface_distances(a: np.ndarray, b: np.ndarray) -> np.ndarray:
    """Distances from the boundary of ``a`` to the boundary of ``b``."""
    a = _binarize(a).astype(bool)
    b = _binarize(b).astype(bool)
    # boundary = pixels in the mask with at least one background 4-neighbour
    a_bd = a ^ ndimage.binary_erosion(a, iterations=1, border_value=0)
    b_bd = b ^ ndimage.binary_erosion(b, iterations=1, border_value=0)
    if a_bd.sum() == 0 or b_bd.sum() == 0:
        return np.array([np.inf])
    # distance from every pixel to the nearest boundary pixel of b
    dt_b = ndimage.distance_transform_edt(~b_bd)
    return dt_b[a_bd]


def hd95(pred: np.ndarray, gt: np.ndarray) -> float:
    """95th-percentile symmetric Hausdorff distance, in pixels."""
    d_pg = _surface_distances(pred, gt)
    d_gp = _surface_distances(gt, pred)
    both = np.concatenate([d_pg, d_gp])
    if not np.all(np.isfinite(both)):
        return float("inf")
    return float(np.percentile(both, 95))


def boundary_iou(pred: np.ndarray, gt: np.ndarray, dilation_ratio: float = 0.02) -> float:
    """Boundary IoU [47]: IoU of the mask boundaries dilated by a band whose
    width scales with the image diagonal."""
    p, g = _binarize(pred), _binarize(gt)
    diag = np.sqrt(p.shape[0] ** 2 + p.shape[1] ** 2)
    d = max(1, int(round(dilation_ratio * diag)))

    def band(m):
        er = ndimage.binary_erosion(m, iterations=d, border_value=0)
        return m & ~er

    pb, gb = band(p), band(g)
    inter = float((pb & gb).sum())
    union = float((pb | gb).sum())
    return inter / union if union > 0 else 1.0


def ece(probs: np.ndarray, gt: np.ndarray, n_bins: int = 15) -> float:
    """Expected Calibration Error [48] over foreground-probability bins."""
    probs = np.asarray(probs, float).reshape(-1)
    g = _binarize(gt).reshape(-1)
    conf = np.where(probs >= 0.5, probs, 1 - probs)
    correct = (_binarize(probs) == g).astype(float)
    edges = np.linspace(0, 1, n_bins + 1)
    e = 0.0
    N = probs.size
    for i in range(n_bins):
        lo, hi = edges[i], edges[i + 1]
        m = (conf > lo) & (conf <= hi) if i > 0 else (conf >= lo) & (conf <= hi)
        if m.sum() == 0:
            continue
        e += (m.sum() / N) * abs(correct[m].mean() - conf[m].mean())
    return float(e)


def artifact_energy(feat: np.ndarray, token_size: int, n_harmonics: int = 3) -> float:
    """E_art: spectral power at the harmonics of the token frequency (Section VI-C).

    Given a final-block feature map ``feat`` of shape ``(C, Hf, Wf)``: subtract
    the per-channel spatial mean, take the 2-D power spectrum, and sum the power
    within one bin of the token-frequency harmonics (excluding DC), as a fraction
    of total spectral power, averaged over channels. The caller normalises by the
    single-encoder EoMT value to report E_art relative to EoMT.
    """
    feat = np.asarray(feat, float)
    if feat.ndim == 2:
        feat = feat[None]
    C, Hf, Wf = feat.shape
    feat = feat - feat.mean(axis=(1, 2), keepdims=True)
    fy = np.fft.fftfreq(Hf)
    fx = np.fft.fftfreq(Wf)
    FX, FY = np.meshgrid(fx, fy)
    base = 1.0 / token_size  # token frequency in cycles/pixel on the feature grid
    tol = 0.5 / max(Hf, Wf)  # "within one bin"
    harm = np.zeros((Hf, Wf), dtype=bool)
    for h in range(1, n_harmonics + 1):
        f = h * base
        harm |= (np.abs(np.abs(FX) - f) < tol) | (np.abs(np.abs(FY) - f) < tol)
    harm[0, 0] = False  # exclude DC
    ratios = []
    for c in range(C):
        P = np.abs(np.fft.fft2(feat[c])) ** 2
        total = P.sum() - P[0, 0]
        ratios.append(P[harm].sum() / total if total > 0 else 0.0)
    return float(np.mean(ratios))


def all_metrics(pred_mask, gt_mask, probs: Optional[np.ndarray] = None) -> dict:
    """Convenience bundle of the accuracy/calibration metrics for one image."""
    out = {
        "dice": dice(pred_mask, gt_mask) * 100,
        "iou": iou(pred_mask, gt_mask) * 100,
        "hd95": hd95(pred_mask, gt_mask),
        "boundary_iou": boundary_iou(pred_mask, gt_mask) * 100,
    }
    if probs is not None:
        out["ece"] = ece(probs, gt_mask)
    return out
