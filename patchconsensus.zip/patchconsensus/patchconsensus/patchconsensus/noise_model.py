"""Dual noise model of Section III-B (Eq 3) and its assumptions A1-A5.

The feature of source ``i = (m, k)`` at pixel ``x`` is modelled as

    h_{m,k}(x) = s(x) + c_m(x) + a_0(x - o_k) + a_m(u_{m,k}(x))        (Eq 3)

with
  * ``s``        lesion signal, shared by all sources;
  * ``c_m``      content-locked error: depends on the image around ``x`` and on
                 encoder ``m``, so it repeats in every patch encoder ``m`` reads
                 (constant over ``k`` for fixed ``m``);  variance sigma_c,m^2;
  * ``a_0``      geometry-locked error: depends only on the in-patch offset, so
                 all encoders share it (constant over ``m`` for fixed ``k``);
                 variance sigma_0^2;
  * ``a_m``      position-locked error: encoder-specific position artifacts and
                 residual noise, independent in every (m, k) cell; variance
                 sigma_a,m^2.

This module is the *data generator* the theory-validation suite draws from: it
produces samples whose true variances are known, so the estimators and bounds
can be checked against ground truth. Assumptions A1-A5 are honoured by
construction here; :mod:`experiments.noise_model_validation` instead *measures*
them on model-like data, mirroring Table VI.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, Optional

import numpy as np

__all__ = ["NoiseParams", "DualNoiseModel"]


@dataclass
class NoiseParams:
    """Ground-truth variances of the dual noise model.

    Attributes
    ----------
    sigma_c : (M,) content-locked variances  sigma_c,m^2
    sigma_a : (M,) position-locked variances  sigma_a,m^2
    sigma_0 : scalar geometry-locked variance sigma_0^2
    """

    sigma_c: np.ndarray
    sigma_a: np.ndarray
    sigma_0: float

    def __post_init__(self) -> None:
        self.sigma_c = np.asarray(self.sigma_c, dtype=np.float64).reshape(-1)
        self.sigma_a = np.asarray(self.sigma_a, dtype=np.float64).reshape(-1)
        if self.sigma_c.shape != self.sigma_a.shape:
            raise ValueError("sigma_c and sigma_a must have the same length M")
        if np.any(self.sigma_c < 0) or np.any(self.sigma_a < 0) or self.sigma_0 < 0:
            raise ValueError("variances must be non-negative")

    @property
    def M(self) -> int:
        return int(self.sigma_c.size)

    @property
    def tau(self) -> np.ndarray:
        """tau_m = sigma_c,m^2 + sigma_a,m^2 (the quantity the 3-cornered hat fixes)."""
        return self.sigma_c + self.sigma_a


class DualNoiseModel:
    """Sampler for Eq (3) with a known :class:`NoiseParams`.

    Parameters
    ----------
    params : NoiseParams
    P : int
        Number of overlapping patches covering the pixel (P_x).
    dim : int
        Channel dimension d per source feature (the model operates per channel;
        ``dim > 1`` just draws i.i.d. channels sharing the variances, per A5).
    rng : np.random.Generator | int | None
    """

    def __init__(self, params: NoiseParams, P: int, dim: int = 1, rng=None):
        self.p = params
        self.P = int(P)
        self.dim = int(dim)
        self.rng = np.random.default_rng(rng)

    @property
    def M(self) -> int:
        return self.p.M

    @property
    def n_sources(self) -> int:
        """|S_x| = M * P_x (Section III-A)."""
        return self.M * self.P

    def sample(self, n: int = 1, signal: float = 0.0) -> Dict[str, np.ndarray]:
        """Draw ``n`` realisations of all sources at one pixel.

        Returns a dict with:
          * ``h``  : (n, M, P, dim) source features h_{m,k}(x)
          * ``eps``: (n, M, P, dim) errors  h - s
          * component arrays ``s, c, a0, a`` for white-box checks.

        The components obey A1-A4 exactly: ``c`` is shared across ``k``;
        ``a0`` is shared across ``m`` but independent across ``k`` (A3, since
        overlapping patches are offset by multiples of tau); ``a`` is
        independent in every (m, k); and all groups are mutually independent
        (A4), hence uncorrelated (A2).
        """
        M, P, d = self.M, self.P, self.dim
        s = np.full((n, 1, 1, d), float(signal))

        # content-locked: one draw per (encoder) shared across patches -> broadcast over k
        c = self.rng.standard_normal((n, M, 1, d)) * np.sqrt(self.p.sigma_c)[None, :, None, None]
        c = np.broadcast_to(c, (n, M, P, d))

        # geometry-locked: one draw per (patch) shared across encoders -> broadcast over m
        a0 = self.rng.standard_normal((n, 1, P, d)) * np.sqrt(self.p.sigma_0)
        a0 = np.broadcast_to(a0, (n, M, P, d))

        # position-locked: independent in every (m, k)
        a = self.rng.standard_normal((n, M, P, d)) * np.sqrt(self.p.sigma_a)[None, :, None, None]

        eps = c + a0 + a
        h = s + eps
        return {
            "h": h, "eps": eps,
            "s": np.broadcast_to(s, (n, M, P, d)).copy(),
            "c": np.array(c), "a0": np.array(a0), "a": a,
        }

    # -- analytic covariance Σ(x) of the stacked source errors (Eq 14) ----
    def covariance(self) -> np.ndarray:
        """True ``MP x MP`` source-error covariance with sources stacked
        ``(m outer, k inner)``: index(m, k) = m * P + k. Matches Eq (14)."""
        from .reliability import source_covariance  # local import to avoid cycle

        return source_covariance(self.p.sigma_c, self.p.sigma_a, self.p.sigma_0, self.P)
