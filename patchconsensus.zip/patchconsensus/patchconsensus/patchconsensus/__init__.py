"""PatchConsensus: Dual-Axis Query Consensus Fusion of Heterogeneous Foundation
Encoders for Artifact-Free Patch-Based Skin Lesion Segmentation.

This package is organised in two layers:

1. A **pure numpy/scipy core** that implements and makes *runnable* every
   closed-form claim of the paper (the dual noise model, DACQ's consensus
   iterations, three-cornered-hat reliability estimation, minimum-variance
   fusion, and the Theorem-1 error prediction). This layer has no GPU / torch
   dependency and is what the theory-validation suite exercises.

2. A **torch model layer** (``patchconsensus.encoders``, ``model``,
   ``student``, ``losses``) that wires the core into a trainable network with
   the three frozen foundation encoders. These modules import torch lazily so
   that the core layer remains importable without it.

Equation numbers in docstrings refer to the manuscript.
"""

from importlib.metadata import PackageNotFoundError, version

try:  # pragma: no cover
    __version__ = version("patchconsensus")
except PackageNotFoundError:  # pragma: no cover
    __version__ = "1.0.0"

# ---- pure-core public API (always importable) ----
from .noise_model import DualNoiseModel, NoiseParams
from .patch import PatchGrid, location_code, token_position
from .reliability import (
    disagreement_energies,
    recover_variances,
    source_covariance,
    min_variance_weights,
    ReliabilityEstimator,
)
from .theory import (
    theorem1_error,
    uniform_weight_error,
    min_variance_error,
    encoder_weights,
    patch_weights,
)
from .dacq import ConsensusADMM, dacq_reference

__all__ = [
    "__version__",
    "DualNoiseModel",
    "NoiseParams",
    "PatchGrid",
    "location_code",
    "token_position",
    "disagreement_energies",
    "recover_variances",
    "source_covariance",
    "min_variance_weights",
    "ReliabilityEstimator",
    "theorem1_error",
    "uniform_weight_error",
    "min_variance_error",
    "encoder_weights",
    "patch_weights",
    "ConsensusADMM",
    "dacq_reference",
]
