"""Label-free reliability estimation and minimum-variance fusion
(Section IV-E, Eq 12-15).

The three disagreements that need no label (Eq 12):
  * ``D_enc,m``   one encoder, two patches     = 2 sigma_0^2 + 2 sigma_a,m^2
  * ``D_pat,mm'`` two encoders, one patch      = tau_m + tau_m'
  * ``D_crs,mm'`` two encoders, two patches    = tau_m + tau_m' + 2 sigma_0^2
with tau_m = sigma_c,m^2 + sigma_a,m^2.

Solving them (Eq 13) recovers the 2M + 1 variances; ``tau_m`` uses the
three-cornered-hat estimator [Grubbs 1948], which needs a third encoder. The
variances assemble into the source covariance Σ(x) (Eq 14), and the fused logit
uses the minimum-variance unbiased weights w* = Σ^{-1} 1 / (1^T Σ^{-1} 1)
(Eq 15).

Source stacking convention: index(m, k) = m * P + k.
"""
from __future__ import annotations

from dataclasses import dataclass
from itertools import combinations, permutations
from typing import Dict, Optional, Tuple

import numpy as np

__all__ = [
    "disagreement_energies",
    "recover_variances",
    "source_covariance",
    "min_variance_weights",
    "ReliabilityEstimator",
]


# --------------------------------------------------------------------------- #
# Eq (12): measured disagreement energies from logits                          #
# --------------------------------------------------------------------------- #
def disagreement_energies(logits: np.ndarray) -> Dict[str, np.ndarray]:
    """Empirical D_enc, D_pat, D_crs from stacked source logits.

    Parameters
    ----------
    logits : (N, M, P) array
        ``N`` samples (e.g. tokens in a 3x3 window, A5) of the per-source logit
        ``ell_{m,k}`` for ``M`` encoders and ``P`` patches.

    Returns
    -------
    dict with
      * ``D_enc`` : (M,)      averaged over all patch pairs k != k'
      * ``D_pat`` : (M, M)    symmetric, zero diagonal
      * ``D_crs`` : (M, M)    symmetric, zero diagonal
    """
    logits = np.asarray(logits, float)
    if logits.ndim != 3:
        raise ValueError("logits must have shape (N, M, P)")
    N, M, P = logits.shape

    # D_enc,m : E[(ell_{m,k} - ell_{m,k'})^2] over k != k'
    D_enc = np.zeros(M)
    if P >= 2:
        acc = []
        for k, kp in combinations(range(P), 2):
            acc.append(np.mean((logits[:, :, k] - logits[:, :, kp]) ** 2, axis=0))
        D_enc = np.mean(acc, axis=0)

    # D_pat,mm' : E[(ell_{m,k} - ell_{m',k})^2] over patches k (same patch, two encoders)
    D_pat = np.zeros((M, M))
    for m, mp in combinations(range(M), 2):
        d = np.mean((logits[:, m, :] - logits[:, mp, :]) ** 2)
        D_pat[m, mp] = D_pat[mp, m] = d

    # D_crs,mm' : E[(ell_{m,k} - ell_{m',k'})^2] over k != k' (two encoders, two patches)
    D_crs = np.zeros((M, M))
    if P >= 2:
        for m, mp in combinations(range(M), 2):
            vals = []
            for k, kp in permutations(range(P), 2):
                vals.append(np.mean((logits[:, m, k] - logits[:, mp, kp]) ** 2))
            D_crs[m, mp] = D_crs[mp, m] = float(np.mean(vals))

    return {"D_enc": D_enc, "D_pat": D_pat, "D_crs": D_crs}


# --------------------------------------------------------------------------- #
# Eq (13): solve for the 2M + 1 variances                                      #
# --------------------------------------------------------------------------- #
def recover_variances(
    energies: Dict[str, np.ndarray], eps_clip: float = 1e-6
) -> Dict[str, np.ndarray]:
    """Recover (sigma_0^2, sigma_a,m^2, sigma_c,m^2) from disagreement energies.

    Implements Eq (13); estimates are averaged over all admissible index pairs
    and clipped at a small positive value (Section IV-E). Requires M >= 3 and
    P >= 2 for full identifiability (Proposition 2a); with fewer, the
    unidentified quantities are returned as NaN.
    """
    D_enc = np.asarray(energies["D_enc"], float)
    D_pat = np.asarray(energies["D_pat"], float)
    D_crs = np.asarray(energies["D_crs"], float)
    M = D_enc.size

    # sigma_0^2 = 1/2 (D_crs,mm' - D_pat,mm'), averaged over all encoder pairs
    pair_mask = ~np.eye(M, dtype=bool)
    if M >= 2 and np.any(D_crs[pair_mask] != 0):
        sigma_0 = 0.5 * np.mean((D_crs - D_pat)[pair_mask])
    else:
        sigma_0 = np.nan

    # sigma_a,m^2 = 1/2 D_enc,m - sigma_0^2
    sigma_a = 0.5 * D_enc - sigma_0

    # tau_m = 1/2 (D_pat,mm' + D_pat,mm'' - D_pat,m'm'')  (three-cornered hat)
    tau = np.full(M, np.nan)
    if M >= 3:
        for m in range(M):
            others = [j for j in range(M) if j != m]
            vals = []
            for mp, mpp in combinations(others, 2):
                vals.append(0.5 * (D_pat[m, mp] + D_pat[m, mpp] - D_pat[mp, mpp]))
            tau[m] = float(np.mean(vals))
    sigma_c = tau - sigma_a

    clip = lambda v: np.clip(v, eps_clip, None) if np.all(np.isfinite(v)) else v
    return {
        "sigma_0": float(np.clip(sigma_0, eps_clip, None)) if np.isfinite(sigma_0) else sigma_0,
        "sigma_a": clip(sigma_a),
        "sigma_c": clip(sigma_c),
        "tau": tau,
    }


# --------------------------------------------------------------------------- #
# Eq (14): source covariance Σ(x)                                              #
# --------------------------------------------------------------------------- #
def source_covariance(
    sigma_c: np.ndarray, sigma_a: np.ndarray, sigma_0: float, P: int
) -> np.ndarray:
    """Assemble Σ(x) = D_c ⊗ J_P + sigma_0^2 (J_M ⊗ I_P) + D_a ⊗ I_P (Eq 14).

    Sources are stacked ``(m outer, k inner)``: index(m, k) = m * P + k, so the
    Kronecker factors act on the encoder axis (left) and patch axis (right).
    Returns an ``MP x MP`` symmetric PSD matrix.
    """
    sigma_c = np.asarray(sigma_c, float).reshape(-1)
    sigma_a = np.asarray(sigma_a, float).reshape(-1)
    M = sigma_c.size
    Dc = np.diag(sigma_c)
    Da = np.diag(sigma_a)
    JP = np.ones((P, P))
    IP = np.eye(P)
    JM = np.ones((M, M))
    return np.kron(Dc, JP) + sigma_0 * np.kron(JM, IP) + np.kron(Da, IP)


# --------------------------------------------------------------------------- #
# Eq (15): minimum-variance unbiased weights                                   #
# --------------------------------------------------------------------------- #
def min_variance_weights(cov: np.ndarray, ridge: float = 0.0) -> np.ndarray:
    """w* = Σ^{-1} 1 / (1^T Σ^{-1} 1) (Eq 15); weights sum to one.

    A tiny ``ridge`` can be added to the diagonal for numerical safety when Σ is
    near-singular (e.g. at image corners before the uniform fallback applies).
    """
    cov = np.asarray(cov, float)
    n = cov.shape[0]
    if ridge:
        cov = cov + ridge * np.eye(n)
    one = np.ones(n)
    sol = np.linalg.solve(cov, one)
    return sol / (one @ sol)


@dataclass
class ReliabilityEstimator:
    """End-to-end reliability pipeline used at inference (Algorithm 1, lines 10-11).

    Given per-source logits over a 3x3 token window, estimates variances without
    labels (Eq 12-13), forms Σ (Eq 14), and returns the minimum-variance fusion
    weights (Eq 15). Falls back to uniform weights over encoders when ``P == 1``
    (corners), where sigma_0^2 is not identifiable (Proposition 2c, Section IV-E).
    """

    eps_clip: float = 1e-6
    ridge: float = 1e-8

    def __call__(self, logits: np.ndarray) -> Dict[str, np.ndarray]:
        logits = np.asarray(logits, float)
        N, M, P = logits.shape
        if P == 1 or M < 3:
            # not identifiable -> uniform over all sources (encoders)
            w = np.full(M * P, 1.0 / (M * P))
            return {"weights": w, "fallback": True, "variances": None, "cov": None}
        energies = disagreement_energies(logits)
        var = recover_variances(energies, self.eps_clip)
        cov = source_covariance(var["sigma_c"], var["sigma_a"], var["sigma_0"], P)
        w = min_variance_weights(cov, ridge=self.ridge)
        return {"weights": w, "fallback": False, "variances": var, "cov": cov}

    @staticmethod
    def fuse(logits_per_source: np.ndarray, weights: np.ndarray) -> np.ndarray:
        """Fused logit ell(x) = w*^T ell(x) (Eq 15).

        ``logits_per_source`` is ``(..., M*P)`` stacked as index(m, k)=m*P+k.
        """
        return np.asarray(logits_per_source, float) @ np.asarray(weights, float)
