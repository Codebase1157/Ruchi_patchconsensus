"""Dual-Axis Consensus Queries (DACQ) — consensus-ADMM core (Section IV-D, V-C).

DACQ treats the ``n = M*K`` sources as agents that must agree on one query
matrix ``z`` (Eq 7-10). The trained network replaces the exact proximal step
with an encoder block (algorithm unrolling); here we provide the *exact*
numpy reference on quadratic objectives, which is what Proposition 3 and
Lemma 1 are about and what the convergence test (mirroring Fig. 8) runs.

Scaled consensus-ADMM updates (Eq 7-9) with per-source penalties rho_i (Eq 10):

    q_i <- argmin_q  F_i(q) + (rho_i / 2) || q - z + u_i ||^2        (Eq 7 / 21)
    z   <- sum_i rho_i (q_i + u_i) / sum_i rho_i                     (Eq 8)
    u_i <- u_i + q_i - z                                            (Eq 9)
    rho_i <- softmax(-|| u_i ||^2 / T)                              (Eq 10)

For quadratic F_i(q) = || q - y_i ||^2 / (2 sigma_i^2) the prox is closed form
and the fixed point is (Lemma 1):

    q_i* = z*,   u_i* = -(1/rho_i) grad F_i(z*),   sum_i grad F_i(z*) = 0,

so with equal penalties z* is the inverse-variance mean of the y_i and
|| u_i || grows with a source's disagreement — the justification for the
down-weighting in Eq (10).
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable, Dict, List, Optional

import numpy as np

__all__ = ["ConsensusADMM", "dacq_reference", "inverse_variance_mean"]


def inverse_variance_mean(y: np.ndarray, sigma2: np.ndarray) -> np.ndarray:
    """z* = (sum_i y_i / sigma_i^2) / (sum_i 1 / sigma_i^2) — the optimum of the
    quadratic consensus problem (Lemma 1 corollary)."""
    y = np.asarray(y, float)
    prec = 1.0 / np.asarray(sigma2, float)
    return (prec[:, None] * y).sum(0) / prec.sum()


@dataclass
class ConsensusADMM:
    """Exact consensus-ADMM on quadratic source objectives (Eq 21, 8, 9, 10).

    Parameters
    ----------
    y : (n, d) array
        Per-source estimates y_i (the quadratic objective's centres).
    sigma2 : (n,) array
        Per-source objective variances sigma_i^2 (``F_i = ||q - y_i||^2 / 2sigma_i^2``).
    T : float
        Temperature of the reliability softmax (Eq 10).
    adaptive_rho : bool
        If True, update rho_i by Eq (10). The paper freezes rho after block 2;
        set ``freeze_after`` to reproduce that.
    freeze_after : int | None
        Iteration index after which rho_i is held constant (Section IV-D: "frozen
        after the second block" -> ``freeze_after = 2``).
    """

    y: np.ndarray
    sigma2: np.ndarray
    T: float = 1.0
    adaptive_rho: bool = True
    freeze_after: Optional[int] = 2

    def __post_init__(self) -> None:
        self.y = np.asarray(self.y, float)
        if self.y.ndim == 1:
            self.y = self.y[:, None]
        self.sigma2 = np.asarray(self.sigma2, float).reshape(-1)
        self.n, self.d = self.y.shape
        if self.sigma2.size != self.n:
            raise ValueError("sigma2 must have one entry per source")

    @staticmethod
    def _softmax_neg_sq(u: np.ndarray, T: float) -> np.ndarray:
        e = -np.sum(u ** 2, axis=1) / T
        e = e - e.max()
        w = np.exp(e)
        return w / w.sum()

    def run(self, n_iter: int = 8, record: bool = True) -> Dict[str, object]:
        """Run ``n_iter`` iterations. Returns final (z, q, u, rho) and, if
        ``record``, per-iteration primal/dual residual and objective histories
        (the quantities plotted in Fig. 8)."""
        n, d = self.n, self.d
        z = self.y.mean(0).copy()
        q = np.tile(z, (n, 1))
        u = np.zeros((n, d))
        rho = np.full(n, 1.0 / n)

        hist = {"primal": [], "dual": [], "objective": [], "disagreement": []}
        prev_z = z.copy()

        for t in range(n_iter):
            # Eq (21): closed-form prox for quadratic F_i
            # q_i = (y_i / sigma_i^2 + rho_i (z - u_i)) / (1/sigma_i^2 + rho_i)
            inv_s = 1.0 / self.sigma2
            denom = inv_s + rho
            q = (self.y * inv_s[:, None] + rho[:, None] * (z - u)) / denom[:, None]

            # Eq (8): weighted-mean consensus
            z = (rho[:, None] * (q + u)).sum(0) / rho.sum()

            # Eq (9): dual update
            u = u + q - z

            # Eq (10): reliability, optionally frozen after `freeze_after`
            if self.adaptive_rho and (self.freeze_after is None or t < self.freeze_after):
                rho = self._softmax_neg_sq(u, self.T)

            if record:
                primal = float(np.sqrt(np.mean(np.sum((q - z) ** 2, axis=1))))
                dual = float(np.linalg.norm(z - prev_z))
                obj = float(np.sum(inv_s * np.sum((q - self.y) ** 2, axis=1) / 2.0))
                dis = float(np.mean(np.linalg.norm(q - z, axis=1)))
                hist["primal"].append(primal)
                hist["dual"].append(dual)
                hist["objective"].append(obj)
                hist["disagreement"].append(dis)
            prev_z = z.copy()

        return {"z": z, "q": q, "u": u, "rho": rho, "history": hist}


def dacq_reference(
    y: np.ndarray,
    sigma2: np.ndarray,
    n_iter: int = 4,
    T: float = 1.0,
    freeze_after: Optional[int] = 2,
) -> np.ndarray:
    """Convenience wrapper: run DACQ and return the consensus query ``z``.

    Mirrors the role of the DACQ module at inference (Algorithm 1, lines 3-8),
    but with the exact quadratic prox standing in for the encoder block, so it
    is runnable without the foundation encoders. With default ``n_iter`` it uses
    the paper's ``L2 = 4`` unrolled blocks.
    """
    return ConsensusADMM(y, sigma2, T=T, freeze_after=freeze_after).run(n_iter, record=False)["z"]
