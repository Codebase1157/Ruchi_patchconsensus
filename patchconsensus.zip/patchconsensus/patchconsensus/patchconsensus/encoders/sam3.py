"""SAM 3 image-encoder [16] (Section IV-C).

Uses the SAM 3 image encoder (ViT-based) as the third, promptable-segmenter
source. Only the image encoder is used; the prompt/mask decoder is dropped since
PatchConsensus is encoder-only. Weights from the SAM 3 release
(https://github.com/facebookresearch/sam3); falls back to a stub when
unavailable.
"""
from __future__ import annotations

import torch

from .base import FrozenEncoder, register_encoder

__all__ = ["SAM3Encoder"]

# SAM 3 image encoder treated as ViT-L-scale for the shared interface
_DIM, _DEPTH, _PATCH = 1024, 24, 16


@register_encoder("sam3")
class SAM3Encoder(FrozenEncoder):
    def __init__(self, L2: int = 4, lora_rank: int = 16, stub: bool = False,
                 weights: str = "facebook/sam3", **kw):
        super().__init__(dim=_DIM, depth=_DEPTH, patch_size=_PATCH, L2=L2,
                         lora_rank=lora_rank, stub=True)
        if stub:
            return
        self._load_real(weights, L2, lora_rank)

    def _load_real(self, weights: str, L2: int, lora_rank: int) -> None:
        try:
            # The SAM 3 image encoder exposes a ModuleList of transformer blocks;
            # we adapt whatever attribute name the release uses.
            from sam3 import build_sam3_image_encoder  # type: ignore
            enc = build_sam3_image_encoder(weights)
            self.backbone = enc
            self.blocks = getattr(enc, "blocks", getattr(enc, "layers"))
            self.patch_embed_real = getattr(enc, "patch_embed")
            self._freeze_except_last(L2, lora_rank)
            self.stub = False
        except Exception as e:  # pragma: no cover
            import warnings
            warnings.warn(f"SAM 3 weights unavailable ({e}); using stub.")

    def tokenize(self, patch: torch.Tensor) -> torch.Tensor:
        if self.stub:
            return super().tokenize(patch)
        x = self.patch_embed_real(patch)
        if x.dim() == 4:  # (B, d, G, G) -> (B, N, d)
            x = x.flatten(2).transpose(1, 2)
        return x
