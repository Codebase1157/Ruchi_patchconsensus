"""DINOv3 ViT-L/16 encoder [13] (Section IV-C).

Loads the official DINOv3 ViT-L/16 backbone and exposes it through
:class:`FrozenEncoder`. Weights are not redistributed; see docs/REPRODUCE.md for
how to obtain them. Falls back to a stub when weights/timm are unavailable.
"""
from __future__ import annotations

import torch
import torch.nn as nn

from .base import FrozenEncoder, register_encoder, inject_lora

__all__ = ["DINOv3Encoder"]

# ViT-L/16: width 1024, depth 24, patch 16
_DIM, _DEPTH, _PATCH = 1024, 24, 16


@register_encoder("dinov3")
class DINOv3Encoder(FrozenEncoder):
    def __init__(self, L2: int = 4, lora_rank: int = 16, stub: bool = False,
                 weights: str = "facebook/dinov3-vitl16", **kw):
        super().__init__(dim=_DIM, depth=_DEPTH, patch_size=_PATCH, L2=L2,
                         lora_rank=lora_rank, stub=True)  # build interface first
        if stub:
            return
        self._load_real(weights, L2, lora_rank)

    def _load_real(self, weights: str, L2: int, lora_rank: int) -> None:
        try:
            import timm
            backbone = timm.create_model(
                "vit_large_patch16_dinov3.lvd_1689m", pretrained=True, num_classes=0,
            )
            self.backbone = backbone
            self.blocks = backbone.blocks
            self.patch_embed_real = backbone.patch_embed
            self._freeze_except_last(L2, lora_rank)
            self.stub = False
        except Exception as e:  # pragma: no cover
            import warnings
            warnings.warn(f"DINOv3 weights unavailable ({e}); using stub.")

    def tokenize(self, patch: torch.Tensor) -> torch.Tensor:
        if self.stub:
            return super().tokenize(patch)
        x = self.patch_embed_real(patch)
        x = self.backbone._pos_embed(x) if hasattr(self.backbone, "_pos_embed") else x
        return x
