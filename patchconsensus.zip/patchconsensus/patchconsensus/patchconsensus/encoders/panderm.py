"""PanDerm ViT-L encoder [14] (Section IV-C).

PanDerm is a dermatology foundation model pretrained on >2M clinical images. It
is the domain-specific encoder of the three, contributing content that the two
natural-image encoders miss. Weights are obtained from the PanDerm release (see
docs/REPRODUCE.md); falls back to a stub when unavailable.
"""
from __future__ import annotations

import torch

from .base import FrozenEncoder, register_encoder

__all__ = ["PanDermEncoder"]

_DIM, _DEPTH, _PATCH = 1024, 24, 16


@register_encoder("panderm")
class PanDermEncoder(FrozenEncoder):
    def __init__(self, L2: int = 4, lora_rank: int = 16, stub: bool = False,
                 weights: str = "PanDerm/PanDerm-ViT-L", **kw):
        super().__init__(dim=_DIM, depth=_DEPTH, patch_size=_PATCH, L2=L2,
                         lora_rank=lora_rank, stub=True)
        if stub:
            return
        self._load_real(weights, L2, lora_rank)

    def _load_real(self, weights: str, L2: int, lora_rank: int) -> None:
        try:
            import timm
            backbone = timm.create_model("vit_large_patch16_224", pretrained=False, num_classes=0)
            state = torch.load(weights, map_location="cpu") if weights.endswith((".pth", ".pt")) else None
            if state is not None:
                backbone.load_state_dict(state.get("model", state), strict=False)
            self.backbone = backbone
            self.blocks = backbone.blocks
            self.patch_embed_real = backbone.patch_embed
            self._freeze_except_last(L2, lora_rank)
            self.stub = False
        except Exception as e:  # pragma: no cover
            import warnings
            warnings.warn(f"PanDerm weights unavailable ({e}); using stub.")

    def tokenize(self, patch: torch.Tensor) -> torch.Tensor:
        if self.stub:
            return super().tokenize(patch)
        x = self.patch_embed_real(patch)
        return self.backbone._pos_embed(x) if hasattr(self.backbone, "_pos_embed") else x
