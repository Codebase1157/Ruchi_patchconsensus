"""Heterogeneous frozen foundation encoders with a shared query space
(Section IV-C). Importing this subpackage requires torch.

The three encoders of the paper:
  * DINOv3 ViT-L/16   [13]
  * PanDerm ViT-L     [14]
  * SAM 3 image enc.  [16]
all stay frozen except rank-16 LoRA adapters in their last ``L2`` blocks, and
expose a common interface (:class:`FrozenEncoder`) so DACQ can drive them with
one shared set of mask queries.
"""
from .base import FrozenEncoder, LoRALinear, QueryBridge, build_encoder, ENCODER_REGISTRY

__all__ = ["FrozenEncoder", "LoRALinear", "QueryBridge", "build_encoder", "ENCODER_REGISTRY"]
