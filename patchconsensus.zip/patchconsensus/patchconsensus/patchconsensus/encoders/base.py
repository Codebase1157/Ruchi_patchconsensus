"""Base classes for the frozen foundation encoders (Section IV-C).

Key pieces
----------
* :class:`LoRALinear`  rank-r low-rank adapter [36] wrapping a frozen ``nn.Linear``.
* :class:`QueryBridge` the learned maps A_m: R^d -> R^{d_m} and B_m: R^{d_m} -> R^d
  (Eq 6) that move a shared-space query into encoder m and back.
* :class:`FrozenEncoder` abstract interface. A concrete encoder must expose its
  transformer blocks as a list so DACQ can run the *last* ``L2`` of them jointly
  on patch tokens and queries (EoMT-style), while the first ``L_m - L2`` blocks
  run once per patch to produce the tokens ``X_{m,k}``.

A ``stub=True`` mode builds a tiny randomly-initialised ViT with the right
interface, so the architecture, training loop and shapes can be exercised on a
machine without the real multi-GB checkpoints (used by the smoke test).
"""
from __future__ import annotations

import math
from typing import Dict, List, Optional, Tuple, Type

import torch
import torch.nn as nn
import torch.nn.functional as F

__all__ = ["LoRALinear", "QueryBridge", "FrozenEncoder", "build_encoder", "ENCODER_REGISTRY"]


# --------------------------------------------------------------------------- #
# LoRA adapter [36]                                                            #
# --------------------------------------------------------------------------- #
class LoRALinear(nn.Module):
    """Frozen linear layer + trainable low-rank update ``B A`` of rank ``r``."""

    def __init__(self, base: nn.Linear, r: int = 16, alpha: int = 16, dropout: float = 0.0):
        super().__init__()
        self.base = base
        for p in self.base.parameters():
            p.requires_grad_(False)
        self.r = r
        self.scaling = alpha / r
        self.A = nn.Parameter(torch.zeros(r, base.in_features))
        self.B = nn.Parameter(torch.zeros(base.out_features, r))
        nn.init.kaiming_uniform_(self.A, a=math.sqrt(5))
        nn.init.zeros_(self.B)
        self.drop = nn.Dropout(dropout)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.base(x) + self.scaling * F.linear(F.linear(self.drop(x), self.A), self.B)


def inject_lora(module: nn.Module, r: int = 16, alpha: int = 16) -> int:
    """Replace every ``nn.Linear`` in ``module`` with a :class:`LoRALinear`.
    Returns the number of layers wrapped."""
    n = 0
    for name, child in list(module.named_children()):
        if isinstance(child, nn.Linear):
            setattr(module, name, LoRALinear(child, r=r, alpha=alpha))
            n += 1
        else:
            n += inject_lora(child, r=r, alpha=alpha)
    return n


# --------------------------------------------------------------------------- #
# Shared-space query bridge (Eq 6)                                             #
# --------------------------------------------------------------------------- #
class QueryBridge(nn.Module):
    """A_m (into encoder m) and B_m (back to shared space) of Eq (6)."""

    def __init__(self, d_shared: int, d_enc: int):
        super().__init__()
        self.A = nn.Linear(d_shared, d_enc)   # R^d -> R^{d_m}
        self.B = nn.Linear(d_enc, d_shared)   # R^{d_m} -> R^d

    def into(self, z: torch.Tensor) -> torch.Tensor:
        return self.A(z)

    def back(self, x: torch.Tensor) -> torch.Tensor:
        return self.B(x)


# --------------------------------------------------------------------------- #
# Minimal ViT block / stub encoder                                             #
# --------------------------------------------------------------------------- #
class _ViTBlock(nn.Module):
    def __init__(self, dim: int, heads: int = 8, mlp_ratio: float = 4.0):
        super().__init__()
        self.norm1 = nn.LayerNorm(dim)
        self.attn = nn.MultiheadAttention(dim, heads, batch_first=True)
        self.norm2 = nn.LayerNorm(dim)
        self.mlp = nn.Sequential(
            nn.Linear(dim, int(dim * mlp_ratio)), nn.GELU(),
            nn.Linear(int(dim * mlp_ratio), dim),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        h = self.norm1(x)
        x = x + self.attn(h, h, h, need_weights=False)[0]
        x = x + self.mlp(self.norm2(x))
        return x


class FrozenEncoder(nn.Module):
    """Common interface over a pretrained ViT.

    Concrete subclasses load real weights; the ``stub`` path builds a tiny ViT
    for shape-exact dry runs. Either way the contract is:
      * ``self.blocks``   : ``nn.ModuleList`` of transformer blocks;
      * ``self.dim``      : encoder width d_m;
      * ``self.patch_size``: token size pi_m;
      * ``tokenize(patch)``: image patch -> (B, N, d_m) tokens with pos-emb;
      * ``run_block(b, x)``: apply block ``b`` jointly to [tokens; queries].
    The last ``L2`` blocks are the ones DACQ unrolls over (Section IV-D).
    """

    name: str = "base"

    def __init__(self, dim: int, depth: int, patch_size: int, L2: int,
                 lora_rank: int = 16, stub: bool = False):
        super().__init__()
        self.dim = dim
        self.depth = depth
        self.patch_size = patch_size
        self.L2 = L2
        self.stub = stub
        if stub:
            self.patch_embed = nn.Conv2d(3, dim, kernel_size=patch_size, stride=patch_size)
            self.pos_embed = nn.Parameter(torch.zeros(1, 1, dim))  # broadcast add
            self.blocks = nn.ModuleList([_ViTBlock(dim) for _ in range(depth)])
            self._freeze_except_last(L2, lora_rank)

    # -- lifecycle -------------------------------------------------------
    def _freeze_except_last(self, L2: int, lora_rank: int) -> None:
        for p in self.parameters():
            p.requires_grad_(False)
        n = 0
        for blk in self.blocks[-L2:]:
            n += inject_lora(blk, r=lora_rank)
        self._n_lora = n

    @property
    def n_trainable(self) -> int:
        return sum(p.numel() for p in self.parameters() if p.requires_grad)

    # -- forward surface -------------------------------------------------
    def tokenize(self, patch: torch.Tensor) -> torch.Tensor:
        """Image patch ``(B, 3, S, S)`` -> tokens ``(B, N, d_m)``."""
        if not self.stub:
            raise NotImplementedError("real encoder must implement tokenize()")
        x = self.patch_embed(patch)                 # (B, d, G, G)
        B, C, Gh, Gw = x.shape
        x = x.flatten(2).transpose(1, 2)            # (B, N, d)
        return x + self.pos_embed

    def run_first_blocks(self, tokens: torch.Tensor) -> torch.Tensor:
        """Blocks ``1 .. L_m - L2`` (Algorithm 1, line 2)."""
        for blk in self.blocks[: self.depth - self.L2]:
            tokens = blk(tokens)
        return tokens

    def run_last_block(self, b: int, x: torch.Tensor) -> torch.Tensor:
        """Apply the ``b``-th of the last ``L2`` blocks jointly to the
        concatenated ``[tokens; queries]`` sequence (EoMT style)."""
        return self.blocks[self.depth - self.L2 + b](x)

    @property
    def token_grid(self) -> Optional[int]:
        return None  # set by caller from patch side S: G_m = S / pi_m


ENCODER_REGISTRY: Dict[str, Type[FrozenEncoder]] = {}


def register_encoder(name: str):
    def deco(cls: Type[FrozenEncoder]):
        cls.name = name
        ENCODER_REGISTRY[name] = cls
        return cls
    return deco


def build_encoder(name: str, L2: int, lora_rank: int = 16, stub: bool = False,
                  **kw) -> FrozenEncoder:
    """Factory. With ``stub=True`` a tiny ViT is built regardless of ``name``,
    so the pipeline runs without the real checkpoints."""
    if stub or name not in ENCODER_REGISTRY:
        spec = _STUB_SPECS.get(name, _STUB_SPECS["dinov3"])
        return FrozenEncoder(dim=spec["dim"], depth=spec["depth"],
                             patch_size=spec["patch_size"], L2=L2,
                             lora_rank=lora_rank, stub=True)
    return ENCODER_REGISTRY[name](L2=L2, lora_rank=lora_rank, stub=False, **kw)


# tiny stand-ins so shapes match the real encoders' interface
_STUB_SPECS = {
    "dinov3": {"dim": 64, "depth": 6, "patch_size": 16},
    "panderm": {"dim": 64, "depth": 6, "patch_size": 16},
    "sam3": {"dim": 64, "depth": 6, "patch_size": 16},
}
