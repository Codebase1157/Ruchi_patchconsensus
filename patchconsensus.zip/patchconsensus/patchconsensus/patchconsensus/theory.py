"""Closed-form predictions of Theorem 1 (Section V-A, Eq 18-19).

Every function here is a property of the noise model (Eq 3) under A1-A4, not of
a trained network (Section V-D). They are used by the theory-validation suite to
check that the *measured* fusion error of :class:`~patchconsensus.noise_model.
DualNoiseModel` samples agrees with the algebra.

Source stacking convention (shared with :mod:`reliability`):
    index(m, k) = m * P + k,  m in [0, M), k in [0, P).
"""
from __future__ import annotations

import numpy as np

__all__ = [
    "encoder_weights",
    "patch_weights",
    "theorem1_error",
    "uniform_weight_error",
    "min_variance_error",
    "content_floor",
    "geometry_floor",
]


def _reshape_w(w: np.ndarray, M: int, P: int) -> np.ndarray:
    w = np.asarray(w, dtype=np.float64).reshape(-1)
    if w.size != M * P:
        raise ValueError(f"weight vector has {w.size} entries, expected M*P = {M * P}")
    return w.reshape(M, P)


def encoder_weights(w: np.ndarray, M: int, P: int) -> np.ndarray:
    """``W_m = sum_k w_{m,k}`` — total weight carried by encoder m (Section V-A)."""
    return _reshape_w(w, M, P).sum(axis=1)


def patch_weights(w: np.ndarray, M: int, P: int) -> np.ndarray:
    """``V_k = sum_m w_{m,k}`` — total weight carried by patch k (Section V-A)."""
    return _reshape_w(w, M, P).sum(axis=0)


def theorem1_error(
    w: np.ndarray, sigma_c: np.ndarray, sigma_a: np.ndarray, sigma_0: float, P: int
) -> float:
    """Left-hand side of Eq (18):

        E[(h - s)^2] = sum_m W_m^2 sigma_c,m^2
                     + sigma_0^2 sum_k V_k^2
                     + sum_{m,k} w_{m,k}^2 sigma_a,m^2.

    This is the three-family decomposition proved in Theorem 1; the companion
    quadratic form ``w^T Σ w`` (Eq 14/15) is computed in
    :func:`reliability.source_covariance` and must equal this value.
    """
    sigma_c = np.asarray(sigma_c, float).reshape(-1)
    sigma_a = np.asarray(sigma_a, float).reshape(-1)
    M = sigma_c.size
    Wm = encoder_weights(w, M, P)
    Vk = patch_weights(w, M, P)
    wmk = _reshape_w(w, M, P)
    content = float(np.sum(Wm ** 2 * sigma_c))
    geometry = float(sigma_0 * np.sum(Vk ** 2))
    position = float(np.sum(wmk ** 2 * sigma_a[:, None]))
    return content + geometry + position


def uniform_weight_error(sigma_c: np.ndarray, sigma_a: np.ndarray, sigma_0: float, P: int) -> float:
    """Eq (19): error of uniform weights ``w_{m,k} = 1/(MP)``:

        (1/M^2) sum_m sigma_c,m^2 + sigma_0^2 / P + (1/(M^2 P)) sum_m sigma_a,m^2.
    """
    sigma_c = np.asarray(sigma_c, float).reshape(-1)
    sigma_a = np.asarray(sigma_a, float).reshape(-1)
    M = sigma_c.size
    return float(
        np.sum(sigma_c) / M ** 2
        + sigma_0 / P
        + np.sum(sigma_a) / (M ** 2 * P)
    )


def min_variance_error(cov: np.ndarray) -> float:
    """Theorem 1(c): minimum error over unbiased weights, ``(1^T Σ^{-1} 1)^{-1}``."""
    cov = np.asarray(cov, float)
    one = np.ones(cov.shape[0])
    sol = np.linalg.solve(cov, one)
    return float(1.0 / (one @ sol))


def content_floor(sigma_c: np.ndarray) -> float:
    """Theorem 1(a): with M = 1 the error cannot fall below sigma_c,1^2."""
    return float(np.asarray(sigma_c, float).reshape(-1)[0])


def geometry_floor(sigma_0: float) -> float:
    """Theorem 1(a): with P = 1 the error cannot fall below sigma_0^2."""
    return float(sigma_0)
