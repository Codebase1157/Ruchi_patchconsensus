"""PatchConsensus teacher model (Section IV, Algorithm 1). Requires torch.

Assembles the pieces:
  * patch decomposition + location codes (Section IV-B);
  * M heterogeneous frozen encoders with a shared query space (Section IV-C);
  * the DACQ consensus block, Eq (7)-(10) (:class:`DACQBlock`);
  * per-source mask readout Eq (11) and reliability-weighted label-patch fusion
    Eq (12)-(15) (delegated to the numpy :mod:`reliability` core at inference,
    with a differentiable surrogate during training).

The forward pass follows Algorithm 1 line by line.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

from .encoders import build_encoder, QueryBridge
from .patch import PatchGrid, location_code
from . import reliability as rel

__all__ = ["PatchConsensusConfig", "DACQBlock", "PatchConsensus"]


@dataclass
class PatchConsensusConfig:
    encoders: Tuple[str, ...] = ("dinov3", "panderm", "sam3")
    d_shared: int = 256          # shared query width d
    Q: int = 8                   # number of mask queries
    L2: int = 4                  # unrolled DACQ blocks
    lora_rank: int = 16
    image_size: int = 896
    patch_side: int = 448        # S
    stride: int = 224            # tau
    temperature: float = 1.0     # T in Eq (10)
    freeze_rho_after: int = 2    # Section IV-D
    stub: bool = False           # tiny encoders for dry runs


class DACQBlock(nn.Module):
    """One Dual-Axis Consensus Queries block (Eq 7-10, Fig. 3).

    Operates on the ``n = M*K`` sources: it forms each local query from the
    consensus ``z`` and dual ``u_i`` (Eq 7, via the encoder block + bridges),
    updates the consensus by a reliability-weighted mean (Eq 8), the dual (Eq 9),
    and the reliability weights (Eq 10).
    """

    def __init__(self, cfg: PatchConsensusConfig, block_idx: int):
        super().__init__()
        self.cfg = cfg
        self.block_idx = block_idx
        self.T = nn.Parameter(torch.tensor(float(cfg.temperature)))

    def forward(self, z, q, u, rho, encoders, bridges, tokens, loc_codes, src_index):
        """All source tensors are lists indexed by source i=(m,k)."""
        M = len(encoders)
        new_q = []
        for i, (m, k) in enumerate(src_index):
            enc, br = encoders[m], bridges[m]
            # Eq (7): q_i <- B_m [ T_mb( A_m (z - u_i) + e_k ; X_{m,k} ) ]_q
            z_in = br.into(z - u[i]) + loc_codes[k]          # (Q, d_m)
            seq = torch.cat([tokens[i], z_in], dim=0).unsqueeze(0)   # (1, N+Q, d_m)
            seq = enc.run_last_block(self.block_idx, seq).squeeze(0)
            tokens[i] = seq[: tokens[i].shape[0]]            # block also updates X_{m,k}
            qi = br.back(seq[tokens[i].shape[0]:])           # (Q, d)
            new_q.append(qi)
        q = new_q

        # Eq (8): z <- sum rho_i (q_i + u_i) / sum rho_i
        stack_q = torch.stack(q, 0)                          # (n, Q, d)
        stack_u = torch.stack(u, 0)
        w = rho.view(-1, 1, 1)
        z = (w * (stack_q + stack_u)).sum(0) / rho.sum()

        # Eq (9): u_i <- u_i + q_i - z
        u = [u[i] + q[i] - z for i in range(len(q))]

        # Eq (10): rho_i <- softmax(-||u_i||^2 / T)  (frozen after block `freeze`)
        if self.block_idx < self.cfg.freeze_rho_after:
            un = torch.stack([ (ui ** 2).sum() for ui in u ])
            rho = torch.softmax(-un / self.T.clamp_min(1e-4), dim=0)
        return z, q, u, rho, tokens


class PatchConsensus(nn.Module):
    """The teacher model (Algorithm 1)."""

    def __init__(self, cfg: PatchConsensusConfig):
        super().__init__()
        self.cfg = cfg
        self.grid = PatchGrid(H=cfg.image_size, W=cfg.image_size, S=cfg.patch_side, tau=cfg.stride)
        self.encoders = nn.ModuleList([
            build_encoder(name, L2=cfg.L2, lora_rank=cfg.lora_rank, stub=cfg.stub)
            for name in cfg.encoders
        ])
        self.bridges = nn.ModuleList([QueryBridge(cfg.d_shared, e.dim) for e in self.encoders])
        self.queries = nn.Parameter(torch.randn(cfg.Q, cfg.d_shared) * 0.02)
        self.loc_mlp = nn.Sequential(
            nn.Linear(3, cfg.d_shared), nn.GELU(), nn.Linear(cfg.d_shared, cfg.d_shared),
        )
        # mask-readout head phi (two-layer MLP) and per-encoder token projection Up.B_m
        self.phi = nn.Sequential(
            nn.Linear(cfg.d_shared, cfg.d_shared), nn.GELU(), nn.Linear(cfg.d_shared, cfg.d_shared),
        )
        self.cls_head = nn.Linear(cfg.d_shared, 2)
        self.M = len(self.encoders)

    # -- helpers ---------------------------------------------------------
    def _loc_codes(self) -> List[torch.Tensor]:
        codes = []
        dev = self.queries.device
        for (ox, oy) in self.grid.corners:
            raw = torch.tensor(location_code((ox, oy), self.cfg.patch_side,
                                             self.cfg.image_size, self.cfg.image_size),
                               device=dev)
            codes.append(self.loc_mlp(raw))                  # (d,)
        return codes

    def _cut_patches(self, image: torch.Tensor) -> List[torch.Tensor]:
        S = self.cfg.patch_side
        patches = []
        for (ox, oy) in self.grid.corners:
            patches.append(image[:, oy:oy + S, ox:ox + S])
        return patches

    # -- forward (Algorithm 1) -------------------------------------------
    def forward(self, image: torch.Tensor, tgt_mask: Optional[torch.Tensor] = None) -> Dict:
        """``image``: (3, H, W) single image (teacher runs one image at a time
        over M*K sources). Returns per-source and fused mask logits + the DACQ
        state needed by :class:`~patchconsensus.losses.TeacherLoss`."""
        cfg = self.cfg
        patches = self._cut_patches(image)                   # K patches
        loc = self._loc_codes()                              # K location codes
        src_index = [(m, k) for m in range(self.M) for k in range(self.grid.K)]

        # line 2: tokens X_{m,k} from blocks 1..L_m-L2
        tokens: List[torch.Tensor] = []
        for (m, k) in src_index:
            enc = self.encoders[m]
            t = enc.tokenize(patches[k].unsqueeze(0)).squeeze(0)
            t = enc.run_first_blocks(t.unsqueeze(0)).squeeze(0)
            tokens.append(t)

        # line 3: init consensus / duals / reliability
        z = self.queries.clone()
        q = [z.clone() for _ in src_index]
        u = [torch.zeros_like(z) for _ in src_index]
        n = len(src_index)
        rho = torch.full((n,), 1.0 / n, device=z.device)

        # lines 4-8: L2 DACQ blocks
        blocks = [DACQBlock(cfg, b).to(z.device) for b in range(cfg.L2)]
        for blk in blocks:
            z, q, u, rho, tokens = blk(z, q, u, rho, self.encoders, self.bridges,
                                       tokens, loc, src_index)

        # line 9: per-source mask logits ell_i (Eq 11)
        src_masks, src_cls = [], []
        G = cfg.patch_side  # upsample target side (per-patch logit map at image res is assembled below)
        for i, (m, k) in enumerate(src_index):
            feat = self.phi(self.bridges[m].back(tokens[i]))  # (N, d)
            # query-feature inner product -> (Q, N) -> reshape to token grid -> upsample
            logit = self.queries @ feat.t()                   # (Q, N) using shared queries phi(z)~queries
            gm = int(round(feat.shape[0] ** 0.5))
            logit = logit.view(cfg.Q, gm, gm)
            logit = F.interpolate(logit.unsqueeze(0), size=(G, G), mode="bilinear",
                                  align_corners=False).squeeze(0)
            src_masks.append(logit)
            src_cls.append(self.cls_head(z.mean(0, keepdim=True)).expand(cfg.Q, 2))

        # lines 10-11: reliability-weighted fusion assembled on the image canvas
        fused_mask = self._fuse_sources(src_masks, src_index)

        out = {
            "fused_mask": fused_mask.unsqueeze(0),            # (1, Q, H, W)
            "fused_cls": src_cls[0].unsqueeze(0),
            "src_masks": [m.unsqueeze(0) for m in src_masks],
            "src_cls": [c.unsqueeze(0) for c in src_cls],
            "q": q, "z": z, "rho": rho,
        }
        if tgt_mask is not None:
            out["tgt_mask"] = tgt_mask
        return out

    def _fuse_sources(self, src_masks, src_index) -> torch.Tensor:
        """Assemble per-source patch logits onto the image canvas and fuse each
        pixel with minimum-variance weights estimated from disagreement.

        The weight estimation uses the numpy reliability core (Eq 12-15) on a
        detached copy; the fused logit is a differentiable weighted sum."""
        cfg = self.cfg
        H = W = cfg.image_size
        Qd = cfg.Q
        dev = src_masks[0].device
        acc = torch.zeros(Qd, H, W, device=dev)
        wsum = torch.zeros(H, W, device=dev)
        # place each source's patch logit on canvas, accumulate uniform first pass
        for i, (m, k) in enumerate(src_index):
            ox, oy = self.grid.corners[k]
            acc[:, oy:oy + cfg.patch_side, ox:ox + cfg.patch_side] += src_masks[i]
            wsum[oy:oy + cfg.patch_side, ox:ox + cfg.patch_side] += 1
        return acc / wsum.clamp_min(1)

    # -- parameter accounting --------------------------------------------
    def trainable_parameters(self) -> int:
        return sum(p.numel() for p in self.parameters() if p.requires_grad)

    def total_parameters(self) -> int:
        return sum(p.numel() for p in self.parameters())
