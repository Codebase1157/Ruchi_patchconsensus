"""Deterministic seeding across numpy, python and (if present) torch."""
from __future__ import annotations

import os
import random

import numpy as np

__all__ = ["seed_everything"]


def seed_everything(seed: int = 0, deterministic: bool = True) -> int:
    """Seed python, numpy and torch RNGs. Returns the seed for logging.

    The five-seed protocol of Section VI-C uses seeds 0..4 by default
    (see ``configs/default.yaml``).
    """
    os.environ["PYTHONHASHSEED"] = str(seed)
    random.seed(seed)
    np.random.seed(seed)
    try:  # torch is optional for the core/validation layer
        import torch

        torch.manual_seed(seed)
        if torch.cuda.is_available():
            torch.cuda.manual_seed_all(seed)
        if deterministic:
            torch.backends.cudnn.deterministic = True
            torch.backends.cudnn.benchmark = False
            os.environ.setdefault("CUBLAS_WORKSPACE_CONFIG", ":4096:8")
    except Exception:  # pragma: no cover
        pass
    return seed
