"""Structured logging: console logger, JSONL run logs, and table loggers that
emit both machine-readable (CSV/JSON) and human-readable (Markdown) table files.

The ``TableLogger`` is what writes the per-table log files under ``logs/tables/``
so that every table in the paper (I-VII) has a corresponding reproducible log.
"""
from __future__ import annotations

import csv
import json
import logging
import sys
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional, Sequence

import numpy as np

__all__ = ["get_logger", "RunLogger", "TableLogger", "format_mean_std"]


# --------------------------------------------------------------------------- #
# Console logger                                                              #
# --------------------------------------------------------------------------- #
def get_logger(name: str = "patchconsensus", level: int = logging.INFO) -> logging.Logger:
    logger = logging.getLogger(name)
    if not logger.handlers:
        h = logging.StreamHandler(sys.stdout)
        fmt = logging.Formatter("[%(asctime)s][%(name)s][%(levelname)s] %(message)s",
                                datefmt="%Y-%m-%d %H:%M:%S")
        h.setFormatter(fmt)
        logger.addHandler(h)
        logger.setLevel(level)
        logger.propagate = False
    return logger


def format_mean_std(mean: float, std: Optional[float] = None, dec: int = 1) -> str:
    """Render ``mean +/- std`` the way the paper's tables do."""
    if std is None or (isinstance(std, float) and np.isnan(std)):
        return f"{mean:.{dec}f}"
    return f"{mean:.{dec}f}±{std:.{dec}f}"


# --------------------------------------------------------------------------- #
# Per-run JSONL logger (one line per logged event: metrics, config, checkpoint) #
# --------------------------------------------------------------------------- #
@dataclass
class RunLogger:
    """Append-only JSONL run log plus a mirrored console line.

    Each ``log(...)`` call writes a timestamped JSON record, so a training run,
    a validation run, or the smoke test all leave a replayable trace under
    ``logs/runs/<run_name>.jsonl``.
    """

    run_name: str
    log_dir: str = "logs/runs"
    console: bool = True
    _fh: object = field(default=None, init=False, repr=False)

    def __post_init__(self) -> None:
        Path(self.log_dir).mkdir(parents=True, exist_ok=True)
        self.path = Path(self.log_dir) / f"{self.run_name}.jsonl"
        self._fh = open(self.path, "a", encoding="utf-8")
        self._logger = get_logger(f"run:{self.run_name}")

    def log(self, event: str, **fields) -> None:
        rec = {"t": time.time(), "iso": time.strftime("%Y-%m-%dT%H:%M:%S"), "event": event}
        rec.update(_jsonable(fields))
        self._fh.write(json.dumps(rec) + "\n")
        self._fh.flush()
        if self.console:
            kv = " ".join(f"{k}={v}" for k, v in fields.items() if not isinstance(v, (list, dict)))
            self._logger.info(f"{event} {kv}".strip())

    def close(self) -> None:
        if self._fh:
            self._fh.close()
            self._fh = None

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()


# --------------------------------------------------------------------------- #
# Table logger: CSV + JSON + Markdown for one paper table                      #
# --------------------------------------------------------------------------- #
@dataclass
class TableLogger:
    """Accumulate rows for one table and write CSV, JSON and Markdown.

    Parameters
    ----------
    table_id : e.g. "II"
    title    : human-readable caption
    columns  : ordered column names
    out_dir  : where the three files are written
    """

    table_id: str
    title: str
    columns: Sequence[str]
    out_dir: str = "logs/tables"
    rows: List[Dict[str, object]] = field(default_factory=list)
    notes: List[str] = field(default_factory=list)

    def add_row(self, **row) -> None:
        self.rows.append(dict(row))

    def add_note(self, note: str) -> None:
        self.notes.append(note)

    # -- writers ---------------------------------------------------------
    def _stem(self) -> Path:
        d = Path(self.out_dir)
        d.mkdir(parents=True, exist_ok=True)
        return d / f"table_{self.table_id}"

    def write(self) -> Dict[str, str]:
        stem = self._stem()
        paths = {
            "csv": str(stem.with_suffix(".csv")),
            "json": str(stem.with_suffix(".json")),
            "md": str(stem.with_suffix(".md")),
        }
        # CSV
        with open(paths["csv"], "w", newline="", encoding="utf-8") as f:
            w = csv.DictWriter(f, fieldnames=list(self.columns))
            w.writeheader()
            for r in self.rows:
                w.writerow({c: r.get(c, "") for c in self.columns})
        # JSON
        with open(paths["json"], "w", encoding="utf-8") as f:
            json.dump(
                {"table_id": self.table_id, "title": self.title,
                 "columns": list(self.columns), "rows": self.rows, "notes": self.notes},
                f, indent=2,
            )
        # Markdown
        with open(paths["md"], "w", encoding="utf-8") as f:
            f.write(f"## TABLE {self.table_id}\n\n{self.title}\n\n")
            f.write("| " + " | ".join(self.columns) + " |\n")
            f.write("| " + " | ".join("---" for _ in self.columns) + " |\n")
            for r in self.rows:
                f.write("| " + " | ".join(str(r.get(c, "")) for c in self.columns) + " |\n")
            if self.notes:
                f.write("\n")
                for n in self.notes:
                    f.write(f"> {n}\n")
        return paths


def _jsonable(obj):
    if isinstance(obj, dict):
        return {k: _jsonable(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [_jsonable(v) for v in obj]
    if isinstance(obj, np.ndarray):
        return obj.tolist()
    if isinstance(obj, (np.floating,)):
        return float(obj)
    if isinstance(obj, (np.integer,)):
        return int(obj)
    return obj
