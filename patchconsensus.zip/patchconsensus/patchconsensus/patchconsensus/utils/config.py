"""YAML config loader with ``_base_`` inheritance and deep-merge overrides."""
from __future__ import annotations

import copy
from pathlib import Path
from typing import Any, Dict, List, Union

import yaml

__all__ = ["load_config", "deep_merge", "apply_overrides"]


def deep_merge(base: Dict, override: Dict) -> Dict:
    out = copy.deepcopy(base)
    for k, v in override.items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = deep_merge(out[k], v)
        else:
            out[k] = copy.deepcopy(v)
    return out


def load_config(path: Union[str, Path]) -> Dict[str, Any]:
    """Load a YAML config, resolving a chain of ``_base_: other.yaml`` files
    (relative to the including file) by deep-merging child over parent."""
    path = Path(path)
    with open(path) as f:
        cfg = yaml.safe_load(f) or {}
    base = cfg.pop("_base_", None)
    if base:
        parent = load_config(path.parent / base)
        cfg = deep_merge(parent, cfg)
    return cfg


def apply_overrides(cfg: Dict, overrides: Dict) -> Dict:
    """Merge a (possibly nested) overrides dict onto a config."""
    return deep_merge(cfg, overrides or {})
