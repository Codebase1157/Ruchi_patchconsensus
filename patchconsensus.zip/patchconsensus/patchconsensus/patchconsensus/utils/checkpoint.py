"""Checkpointing.

Two backends:
  * torch state-dicts (``.pth``) for the real teacher/student models;
  * a dependency-free numpy ``.npz`` backend used by the synthetic smoke test,
    so a real, loadable checkpoint is produced and shipped even without torch.

A sidecar ``<ckpt>.meta.json`` records config, metrics, seed, git hash and
timestamp for every checkpoint, so each saved model is traceable to its run.
"""
from __future__ import annotations

import json
import subprocess
import time
from pathlib import Path
from typing import Dict, Optional

import numpy as np

__all__ = ["save_checkpoint", "load_checkpoint", "git_hash"]


def git_hash(default: str = "unknown") -> str:
    try:
        return subprocess.check_output(
            ["git", "rev-parse", "--short", "HEAD"], stderr=subprocess.DEVNULL
        ).decode().strip()
    except Exception:
        return default


def _write_meta(path: Path, meta: Dict) -> None:
    meta = dict(meta)
    meta.setdefault("saved_at", time.strftime("%Y-%m-%dT%H:%M:%S"))
    meta.setdefault("git", git_hash())
    path.with_suffix(path.suffix + ".meta.json").write_text(json.dumps(meta, indent=2))


def save_checkpoint(state: Dict, path: str, meta: Optional[Dict] = None) -> str:
    """Save ``state``. If values are torch tensors a ``.pth`` is written via
    ``torch.save``; otherwise a numpy ``.npz`` is written. A meta sidecar is
    always written."""
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    try:
        import torch  # noqa

        torch.save(state, p)
    except Exception:
        # numpy fallback: flatten to arrays
        flat = {k: np.asarray(v) for k, v in state.items()
                if isinstance(v, (np.ndarray, list, int, float))}
        np.savez(p.with_suffix(".npz"), **flat)
        p = p.with_suffix(".npz")
    _write_meta(p, meta or {})
    return str(p)


def load_checkpoint(path: str) -> Dict:
    p = Path(path)
    if p.suffix == ".npz":
        with np.load(p, allow_pickle=True) as z:
            return {k: z[k] for k in z.files}
    import torch

    return torch.load(p, map_location="cpu")
