"""Reproducible dataset splitting (Section VI-A). Pure python.

HAM10000 is split by LESION identifier (``lesion_id``) and stratified by
diagnosis, because many images share a lesion; ISIC 2018 is split by PATIENT
where metadata allow. Splitting by group (lesion / patient) rather than image
prevents leakage across train/val/test. Generated split files are released with
the code (``data/splits/*.json``).
"""
from __future__ import annotations

import json
import random
from collections import defaultdict
from pathlib import Path
from typing import Dict, List, Optional, Sequence, Tuple

__all__ = ["make_lesion_split", "make_patient_split", "load_split", "save_split"]


def _grouped_split(
    items: Sequence[Tuple[str, str, Optional[str]]],
    ratios: Tuple[float, float, float],
    seed: int,
    stratify: bool,
) -> Dict[str, List[str]]:
    """Group items by ``group_id`` (2nd field), optionally stratify by label
    (3rd field), and assign whole groups to train/val/test by ``ratios``."""
    rng = random.Random(seed)
    groups: Dict[str, List[str]] = defaultdict(list)
    group_label: Dict[str, str] = {}
    for image_id, group_id, label in items:
        groups[group_id].append(image_id)
        group_label[group_id] = label or "_"

    by_label: Dict[str, List[str]] = defaultdict(list)
    for g, lab in group_label.items():
        by_label[lab if stratify else "_"].append(g)

    split = {"train": [], "val": [], "test": []}
    for lab, gs in by_label.items():
        gs = sorted(gs)
        rng.shuffle(gs)
        n = len(gs)
        n_tr = int(round(ratios[0] * n))
        n_va = int(round(ratios[1] * n))
        chunks = {"train": gs[:n_tr], "val": gs[n_tr:n_tr + n_va], "test": gs[n_tr + n_va:]}
        for s, group_ids in chunks.items():
            for g in group_ids:
                split[s].extend(groups[g])
    for s in split:
        split[s] = sorted(split[s])
    return split


def make_lesion_split(items, ratios=(0.7, 0.1, 0.2), seed=0) -> Dict[str, List[str]]:
    """HAM10000: 70/10/20 by lesion, stratified by diagnosis.

    ``items`` : iterable of ``(image_id, lesion_id, diagnosis)``.
    """
    return _grouped_split(list(items), ratios, seed, stratify=True)


def make_patient_split(items, ratios=(0.7, 0.1, 0.2), seed=0) -> Dict[str, List[str]]:
    """ISIC 2018: by patient. ``items`` : ``(image_id, patient_id, _)``."""
    return _grouped_split(list(items), ratios, seed, stratify=False)


def save_split(split: Dict[str, List[str]], path: str, meta: Optional[Dict] = None) -> None:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    payload = {"meta": meta or {}, "counts": {k: len(v) for k, v in split.items()}, "split": split}
    p.write_text(json.dumps(payload, indent=2))


def load_split(path: str) -> Dict[str, List[str]]:
    payload = json.loads(Path(path).read_text())
    return payload["split"]
