"""Data layer: datasets, transforms, split generation.

Importing the torch-backed :class:`LesionDataset` requires torch; the split
helpers are pure-python and importable without it.
"""
from .splits import make_lesion_split, make_patient_split, load_split, save_split

__all__ = ["make_lesion_split", "make_patient_split", "load_split", "save_split"]
