"""Dataset classes for the four benchmarks (Section VI-A). Requires torch.

A :class:`LesionDataset` reads image/mask pairs listed in a split file, resizes
to 896x896 (keeping patch geometry; ISIC 2024 crops are upsampled bicubically),
and returns ``(image, mask, meta)``. Patchification happens in the model, not
here, so the same dataset feeds teacher (patched) and student (whole image).
"""
from __future__ import annotations

from pathlib import Path
from typing import Callable, Dict, List, Optional

import numpy as np
import torch
from torch.utils.data import Dataset

from .splits import load_split
from .transforms import JointAugment


def _load_image(path: str, size: int) -> torch.Tensor:
    from PIL import Image
    img = Image.open(path).convert("RGB").resize((size, size), Image.BICUBIC)
    return torch.from_numpy(np.asarray(img, dtype=np.float32) / 255.0).permute(2, 0, 1)


def _load_mask(path: str, size: int) -> torch.Tensor:
    from PIL import Image
    m = Image.open(path).convert("L").resize((size, size), Image.NEAREST)
    return (torch.from_numpy(np.asarray(m)) > 127).to(torch.uint8)


class LesionDataset(Dataset):
    def __init__(self, cfg: Dict, split: str = "train", augment: bool = True):
        self.cfg = cfg
        d = cfg["dataset"]
        self.images_dir = Path(d["images"])
        self.masks_dir = Path(d.get("masks", "")) if d.get("masks") else None
        self.size = cfg["image_size"]
        self.split = split
        ids = load_split(d["split_file"])[split] if d.get("split_file") else \
            sorted(p.stem for p in self.images_dir.glob("*"))
        self.ids: List[str] = ids
        self.aug = JointAugment(cfg["augment"]) if (augment and split == "train") else None

    def __len__(self) -> int:
        return len(self.ids)

    def _find(self, directory: Path, stem: str) -> Optional[Path]:
        for ext in (".png", ".jpg", ".jpeg", ".bmp", ".tif", ".tiff"):
            for cand in (directory / f"{stem}{ext}", directory / f"{stem}_segmentation{ext}"):
                if cand.exists():
                    return cand
        return None

    def __getitem__(self, i: int):
        stem = self.ids[i]
        img_path = self._find(self.images_dir, stem)
        image = _load_image(str(img_path), self.size)
        if self.masks_dir is not None and (mp := self._find(self.masks_dir, stem)):
            mask = _load_mask(str(mp), self.size)
        else:
            mask = torch.zeros(self.size, self.size, dtype=torch.uint8)
        if self.aug is not None:
            image, mask = self.aug(image, mask)
        return {"image": image, "mask": mask, "id": stem}
