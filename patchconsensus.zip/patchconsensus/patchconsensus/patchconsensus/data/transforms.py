"""Augmentation and patchification (Section IV-B, VI-D). Requires torch.

Augmentations (flips, 90-degree rotations, scaling, colour jitter) are applied
*identically to all patches of an image*, as required by the patch-consensus
geometry. Patchification uses :class:`~patchconsensus.patch.PatchGrid`.
"""
from __future__ import annotations

import random
from typing import Dict, List, Tuple

import numpy as np
import torch
import torch.nn.functional as F

from ..patch import PatchGrid


class JointAugment:
    """Image+mask augmentation with a single shared random state per image."""

    def __init__(self, cfg: Dict):
        self.cfg = cfg

    def __call__(self, image: torch.Tensor, mask: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        c = self.cfg
        if c.get("hflip") and random.random() < 0.5:
            image, mask = image.flip(-1), mask.flip(-1)
        if c.get("vflip") and random.random() < 0.5:
            image, mask = image.flip(-2), mask.flip(-2)
        if c.get("rot90"):
            k = random.randint(0, 3)
            image, mask = torch.rot90(image, k, (-2, -1)), torch.rot90(mask, k, (-2, -1))
        if "scale" in c:
            lo, hi = c["scale"]
            s = random.uniform(lo, hi)
            image = _rescale_crop(image, s, mode="bilinear")
            mask = _rescale_crop(mask.float(), s, mode="nearest")
        if "color_jitter" in c:
            image = _color_jitter(image, **c["color_jitter"])
        return image, mask


def _rescale_crop(x: torch.Tensor, s: float, mode: str) -> torch.Tensor:
    H, W = x.shape[-2:]
    x = F.interpolate(x.unsqueeze(0), scale_factor=s, mode=mode,
                      align_corners=False if mode == "bilinear" else None).squeeze(0)
    nH, nW = x.shape[-2:]
    if s >= 1:  # centre-crop back
        top, left = (nH - H) // 2, (nW - W) // 2
        return x[..., top:top + H, left:left + W]
    pad = [(W - nW) // 2, W - nW - (W - nW) // 2, (H - nH) // 2, H - nH - (H - nH) // 2]
    return F.pad(x, pad)


def _color_jitter(x, brightness=0.0, contrast=0.0, saturation=0.0, hue=0.0):
    if brightness:
        x = x * (1 + random.uniform(-brightness, brightness))
    if contrast:
        m = x.mean((-2, -1), keepdim=True)
        x = (x - m) * (1 + random.uniform(-contrast, contrast)) + m
    return x.clamp(0, 1)


def patchify(image: torch.Tensor, grid: PatchGrid) -> List[torch.Tensor]:
    """Cut ``image`` (3, H, W) into the grid's ``K`` patches (3, S, S)."""
    S = grid.S
    return [image[:, oy:oy + S, ox:ox + S] for (ox, oy) in grid.corners]
