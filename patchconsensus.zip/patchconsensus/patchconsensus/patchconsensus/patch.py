"""Patch decomposition and location codes (Section III-A, IV-B).

Implements:
  * Eq (1)  the set of patches covering a pixel and its cardinality P_x
  * Eq (2)  the in-patch token position u_{m,k}(x)
  * Eq (5)  the per-patch location code e_k

Pure numpy; no GPU dependency. The torch model re-uses :class:`PatchGrid` to
lay out patches and calls :func:`location_code` to build the MLP input.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import List, Tuple

import numpy as np

__all__ = ["PatchGrid", "token_position", "location_code"]


@dataclass(frozen=True)
class PatchGrid:
    """Regular grid of ``K`` square patches of side ``S`` placed with stride
    ``tau < S`` over an ``H x W`` image (Section III-A).

    With the paper's defaults (H = W = 896, S = 448, tau = 224) this yields a
    3x3 grid, ``K = 9`` patches, and up to ``P = 4`` patches covering an
    interior pixel (Section IV-B).
    """

    H: int = 896
    W: int = 896
    S: int = 448
    tau: int = 224

    def __post_init__(self) -> None:
        if self.tau >= self.S:
            raise ValueError(f"stride tau={self.tau} must be < patch side S={self.S}")
        if self.S > self.H or self.S > self.W:
            raise ValueError("patch side larger than image")

    # -- top-left corners o_k --------------------------------------------
    def _axis_starts(self, extent: int) -> List[int]:
        """Start coordinates along one axis; the last patch is clamped to the
        border so the whole image is covered even when (extent - S) % tau != 0."""
        starts = list(range(0, extent - self.S + 1, self.tau))
        if not starts or starts[-1] != extent - self.S:
            starts.append(extent - self.S)
        return starts

    @property
    def corners(self) -> np.ndarray:
        """``(K, 2)`` array of top-left corners ``o_k = (ox, oy)`` (x=col, y=row)."""
        xs = self._axis_starts(self.W)
        ys = self._axis_starts(self.H)
        return np.array([(ox, oy) for oy in ys for ox in xs], dtype=np.int64)

    @property
    def K(self) -> int:
        return len(self.corners)

    # -- Eq (1): patches covering a pixel --------------------------------
    def patches_covering(self, x: Tuple[int, int]) -> np.ndarray:
        """``K_x = {k : x in Omega_k}`` for pixel ``x = (px, py)`` (Eq 1)."""
        px, py = x
        o = self.corners
        inside = (
            (px >= o[:, 0]) & (px < o[:, 0] + self.S)
            & (py >= o[:, 1]) & (py < o[:, 1] + self.S)
        )
        return np.nonzero(inside)[0]

    def coverage(self, x: Tuple[int, int]) -> int:
        """``P_x = |K_x|`` (Eq 1)."""
        return int(self.patches_covering(x).size)

    def coverage_map(self) -> np.ndarray:
        """``H x W`` map of ``P_x`` for every pixel (useful for corner fallback)."""
        cov = np.zeros((self.H, self.W), dtype=np.int32)
        for (ox, oy) in self.corners:
            cov[oy:oy + self.S, ox:ox + self.S] += 1
        return cov


def token_position(x: Tuple[int, int], o_k: Tuple[int, int], pi_m: int, G_m: int) -> Tuple[int, int]:
    """In-patch token position ``u_{m,k}(x) = floor((x - o_k) / pi_m)`` (Eq 2).

    ``pi_m`` is encoder m's patch/token size, ``G_m = S / pi_m`` the token-grid
    side. The result is clamped to ``{0, ..., G_m - 1}^2``.
    """
    px, py = x
    ox, oy = o_k
    ux = min(max((px - ox) // pi_m, 0), G_m - 1)
    uy = min(max((py - oy) // pi_m, 0), G_m - 1)
    return int(ux), int(uy)


def location_code(o_k: Tuple[int, int], S: int, H: int, W: int) -> np.ndarray:
    """Raw (pre-MLP) location-code features for patch ``k`` (Eq 5).

    Returns ``[o_k^x / W, o_k^y / H, S / W]`` — the vector fed to the shared
    location MLP whose output ``e_k`` is added to the queries of patch ``k``
    in Eq (7). Kept raw here so the torch ``MLP`` owns the learned part.
    """
    ox, oy = o_k
    return np.asarray([ox / W, oy / H, S / W], dtype=np.float32)
