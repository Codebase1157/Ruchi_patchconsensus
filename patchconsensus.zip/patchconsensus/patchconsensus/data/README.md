# Data directory

Datasets are **not** redistributed here; each is governed by its own data-use
agreement. This directory documents the expected layout and holds the artifacts
that *are* released with the code (the split files and our ISIC-2024 masks).

## Expected layout

```
data/
├── HAM10000/
│   ├── images/                 # ISIC_*.jpg
│   ├── masks/                  # ISIC_*_segmentation.png
│   └── HAM10000_metadata.csv   # official metadata (image_id, lesion_id, dx, ...)
├── ISIC2018/
│   ├── images/
│   ├── masks/
│   └── metadata.csv
├── PH2/
│   ├── images/
│   └── masks/
├── ISIC2024/
│   ├── crops/                  # SLICE-3D 15x15 mm crops
│   └── masks_ours/             # our 1,000 annotations (RELEASED, see below)
└── splits/
    ├── ham10000_split.json     # 70/10/20 by lesion id, stratified (RELEASED)
    ├── isic2018_split.json     # by patient (RELEASED)
    └── isic2024_annotated.json # the 1,000 annotated crop ids (RELEASED)
```

## How to obtain the images

| Dataset | Where |
| --- | --- |
| HAM10000 | Harvard Dataverse (Tschandl et al., *Sci. Data* 2018); masks from the authors' human–computer-collaboration release |
| ISIC 2018 Task 1 | ISIC Archive — 2018 challenge |
| PH2 | ADDI project (Mendonça et al. 2013) |
| ISIC 2024 (SLICE-3D) | ISIC Archive — 2024 |

After downloading, verify with:
```bash
python scripts/prepare_data.py --config configs/ham10000.yaml
```

## Released artifacts

- **Split files** (`splits/`): regenerable from metadata with
  `scripts/make_splits.py`, and shipped so results are reproducible without
  rerunning the split.
- **ISIC 2024 masks** (`ISIC2024/masks_ours/`): 1,000 crops — all 393 malignant
  and 607 benign sampled per centre — annotated by two annotators
  (inter-annotator Dice 0.86), consensus used as reference. Scores on this set
  are bounded by 0.86 and are not comparable to the dermoscopy columns.

> The split JSONs and mask PNGs would live here in the full release; this
> scaffold ships the code that produces and consumes them.
