# Theory → code map

Every closed-form result of Section V is implemented in the pure numpy/scipy core and checked numerically by `experiments/validate_theory.py`. This file maps each equation and theorem to the function that realises it and the test that verifies it.

## The model (Section III)

| Paper | Code | Test |
| --- | --- | --- |
| Eq 1 — patches covering a pixel, `P_x` | `patch.PatchGrid.patches_covering`, `.coverage` | `tests/test_patch.py` |
| Eq 2 — in-patch token position `u_{m,k}(x)` | `patch.token_position` | `tests/test_patch.py` |
| Eq 3 — dual noise model `h = s + c_m + a0 + a_m` | `noise_model.DualNoiseModel.sample` | sampler used throughout |
| Eq 5 — location code `e_k` | `patch.location_code` | `tests/test_patch.py` |
| A1–A5 — assumptions | honoured by construction in `DualNoiseModel`; *measured* in `experiments/noise_model_validation.py` (Table VI) | — |

## Theorem 1 — dual-axis attenuation (Section V-A)

The error of a weighted fusion with weights summing to one is

```
E[(h − s)²] = Σ_m W_m² σ_c,m²  +  σ0² Σ_k V_k²  +  Σ_{m,k} w_{m,k}² σ_a,m²  =  wᵀ Σ w      (Eq 18)
```

with `W_m = Σ_k w_{m,k}` (encoder weight) and `V_k = Σ_m w_{m,k}` (patch weight).

| Paper | Code | Checked by |
| --- | --- | --- |
| Eq 18 three-family decomposition | `theory.theorem1_error` | `test_theory.test_decomposition_equals_quadratic_form`; `validate_theory` **T1a** |
| Eq 14 covariance Σ = D_c⊗J_P + σ0²(J_M⊗I_P) + D_a⊗I_P | `reliability.source_covariance` | `test_theory.test_covariance_is_psd`; T1a |
| Eq 19 uniform-weight error | `theory.uniform_weight_error` | `test_theory.test_uniform_weight_formula`; T1b |
| Thm 1(c) minimum `(1ᵀΣ⁻¹1)⁻¹`, attained by Eq 15 | `theory.min_variance_error`, `reliability.min_variance_weights` | `test_theory.test_min_variance_is_minimum`; T1c |
| Thm 1(a) floors: `P=1 ⇒ ≥σ0²`, `M=1 ⇒ ≥σc,1²` | same, with P=1 / M=1 covariances | `test_theory.test_floors`; T1d |

**T1a** draws samples from Eq 3, measures the Monte-Carlo fusion error, and checks it equals both `wᵀΣw` and the three-family decomposition. **T1c** verifies `w*` attains the predicted minimum and that no feasible weighting beats it.

## Proposition 2 — identifiability (Section IV-E, V-B)

The three label-free disagreements (Eq 12), with `τ_m = σc,m² + σa,m²`:

```
D_enc,m   = 2σ0² + 2σa,m²
D_pat,mm' = τ_m + τ_m'
D_crs,mm' = τ_m + τ_m' + 2σ0²
```

solve (Eq 13) to `σ0² = ½(D_crs − D_pat)`, `σa,m² = ½D_enc,m − σ0²`, `τ_m = ½(D_pat,mm' + D_pat,mm'' − D_pat,m'm'')` (three-cornered hat), `σc,m² = τ_m − σa,m²`.

| Paper | Code | Checked by |
| --- | --- | --- |
| Eq 12 disagreement energies | `reliability.disagreement_energies` | `test_reliability.test_energy_closed_forms`; `validate_theory` P2 |
| Eq 13 recovery (3-cornered hat) | `reliability.recover_variances` | `test_reliability.test_three_cornered_hat_recovers_variances`; P2a |
| Prop 2a (M≥3,P≥2 fully identified) | same | P2a |
| Prop 2b (M=2: only τ1+τ2) | same (individual τ_m → NaN) | `validate_theory` P2b |
| Prop 2c (P=1: σ0² not identified) | same (σ0 → NaN) | `test_reliability.test_non_identifiable_at_P1`; P2c |
| Eq 15 fusion weights, corner fallback | `reliability.min_variance_weights`, `ReliabilityEstimator` | `test_reliability.test_corner_fallback_is_uniform` |

## Proposition 3 & Lemma 1 — consensus ADMM (Section IV-D, V-C)

Scaled consensus-ADMM (Eq 7–9) with per-source penalties (Eq 10). For quadratic objectives the exact proximal step is closed-form; `z*` is the inverse-variance mean and `u_i* = −(1/ρ_i)∇F_i(z*)` measures disagreement.

| Paper | Code | Checked by |
| --- | --- | --- |
| Eq 7–10 updates | `dacq.ConsensusADMM.run` | — |
| Prop 3 convergence; Lemma 1 corollary (z→inverse-variance mean) | `dacq.ConsensusADMM`, `dacq.inverse_variance_mean` | `test_dacq.test_converges_to_inverse_variance_mean`; `validate_theory` L1 |
| primal residual → 0 | residual history | `test_dacq.test_primal_residual_decreases`; L1 |
| Lemma 1: ‖u_i‖ largest for the most disagreeing source | `.run` duals | `test_dacq.test_dual_flags_outlier` |
| Eq 10: ρ_i smallest for the outlier | adaptive ρ | `test_dacq.test_adaptive_rho_downweights_outlier` |

The trained network (`model.DACQBlock`) replaces the exact prox with an encoder block (algorithm unrolling) and runs only `L2=4` iterations, so Proposition 3 motivates the design without guaranteeing convergence of the trained network — exactly as stated in Section V-C.

## Scope (Section V-D)

Theorem 1, Proposition 2 and Lemma 1 are exact consequences of the model (Eq 3) under A1–A4; the validation suite confirms the algebra. They are **not** predictions of measured Dice/HD95 — those are measurements (Section VII) and require the real data/weights (Tier B).
