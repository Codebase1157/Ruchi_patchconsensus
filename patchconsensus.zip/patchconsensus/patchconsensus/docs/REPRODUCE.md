# Reproduction procedure

This document gives the exact steps to reproduce (A) the numerical validation of the theory, which runs anywhere, and (B) the paper's benchmark numbers, which need a GPU, the datasets and the pretrained encoder weights.

---

## 0. Environment

```bash
git clone <this-repo> patchconsensus && cd patchconsensus
python -m venv .venv && source .venv/bin/activate

# Tier A only (CPU): numpy, scipy, pyyaml
pip install -e .

# Tier B (training/inference): adds torch, timm, etc.
pip install -e '.[train]'
# dev extras (pytest, ruff):
pip install -e '.[dev]'
```

Python ≥ 3.9. Tier B was run with CUDA 12.x on a single NVIDIA A100 80 GB.

Determinism: every entry point calls `seed_everything(seed)`; the five-seed protocol uses seeds 0–4 (`configs/default.yaml: seeds`).

---

## A. Validate the theory (no data, no weights, CPU)

```bash
bash scripts/reproduce_all.sh quick
```

or individually:

```bash
python experiments/validate_theory.py --seeds 10        # Theorem 1, Prop 2/3, Lemma 1
python experiments/noise_model_validation.py            # assumption tests A1–A5 (Table VI)
python experiments/smoke_test.py                        # end-to-end Algorithm 1 on synthetic data
python experiments/emit_reference_tables.py             # paper Tables I–VII as reference logs
pytest -q                                               # unit tests
```

Outputs (all committed-friendly, under `logs/`):

- `logs/validation/theory_validation.md` — pass/fail per closed-form claim. Expect **11/11 on every seed**.
- `logs/tables/table_VI.md` — measured A1–A5 with bootstrap CIs; A3 ≈ 0.093 (borderline).
- `logs/checkpoints/smoke_student.npz` (+ `.meta.json`) — a real, loadable checkpoint.
- `logs/tables/table_smoke.md` — fusion vs single-encoder vs uniform on a synthetic lesion.
- `logs/runs/*.jsonl` — replayable run traces.

---

## B. Reproduce the benchmark numbers (A100 + data + weights)

### B.1 Datasets

None are redistributed here. Obtain each from its source and place it as below.

| Dataset | Source | Expected path |
| --- | --- | --- |
| HAM10000 | Harvard Dataverse (Tschandl et al. 2018) + segmentation masks | `data/HAM10000/images/`, `data/HAM10000/masks/`, `data/HAM10000/HAM10000_metadata.csv` |
| ISIC 2018 Task 1 | ISIC Archive challenge 2018 | `data/ISIC2018/images/`, `data/ISIC2018/masks/` |
| PH2 | ADDI project (Mendonça et al. 2013) | `data/PH2/images/`, `data/PH2/masks/` |
| ISIC 2024 (SLICE-3D) | ISIC Archive 2024 crops | `data/ISIC2024/crops/`, `data/ISIC2024/masks_ours/` |

Our 1,000 ISIC-2024 annotations and all split files are released with this code under `data/splits/` and `data/ISIC2024/masks_ours/` (the images themselves are not redistributed). See `data/README.md`.

Verify layout:
```bash
python scripts/prepare_data.py --config configs/ham10000.yaml
python scripts/prepare_data.py --config configs/isic2018.yaml
```

### B.2 Splits

HAM10000 is split 70/10/20 by **lesion id** (stratified by diagnosis); ISIC 2018 by **patient**. Regenerate the released splits from metadata:

```bash
python scripts/make_splits.py --dataset ham10000 \
    --metadata data/HAM10000/HAM10000_metadata.csv \
    --out data/splits/ham10000_split.json
python scripts/make_splits.py --dataset isic2018 \
    --metadata data/ISIC2018/metadata.csv \
    --out data/splits/isic2018_split.json
```

### B.3 Pretrained encoder weights

Frozen, except rank-16 LoRA adapters in the last `L2=4` blocks. Obtain and point the configs/encoders at:

| Encoder | Source |
| --- | --- |
| DINOv3 ViT-L/16 | official DINOv3 release [13] (`timm` id `vit_large_patch16_dinov3.*`) |
| PanDerm ViT-L | PanDerm release [14] |
| SAM 3 image encoder | `github.com/facebookresearch/sam3` [16] |

The encoder loaders in `patchconsensus/encoders/` fall back to a tiny stub (with a warning) if weights are missing, so the pipeline still runs for a dry test — but the numbers are meaningless then.

### B.4 Train, distil, evaluate

```bash
# teacher, five seeds (Table II row "PatchConsensus (teacher)")
for s in 0 1 2 3 4; do
  python scripts/train_teacher.py --config configs/teacher.yaml --seed $s
done

# students (Table VII)
for s in 0 1 2 3 4; do
  python scripts/distill_student.py --config configs/student_vitl.yaml --seed $s
  python scripts/distill_student.py --config configs/student_vitb.yaml --seed $s
done

# evaluate on all four sets
python scripts/evaluate.py --config configs/teacher.yaml --split test
python scripts/evaluate.py --config configs/external_tests.yaml --dataset ph2      --split test
python scripts/evaluate.py --config configs/external_tests.yaml --dataset isic2024 --split test

# ablations / design sweeps (Tables IV–V)
python experiments/run_ablation.py --config configs/ablations/ablations.yaml

# aggregate five seeds -> mean ± s.d. + Wilcoxon/Holm + rank-biserial (Tables II,III,VII)
python experiments/aggregate_seeds.py --tables logs/tables
```

Or the whole thing:
```bash
bash scripts/reproduce_all.sh full
```

### B.5 Hyperparameters (Section VI-D)

AdamW; lr 1e-4 (new modules) / 1e-5 (adapters); cosine over 40k iters; batch 8 images (72 patches); flips, 90° rotations, scaling and colour jitter applied identically to all patches of an image; loss weights β=0.5, λc=0.1, λd=1.0, γ=0.5; Q=8 queries, L2=4 blocks. All in `configs/default.yaml`.

### B.6 Cost (Table VII, Section VII-H)

Teacher ≈ 130 GPU-hours; each student distillation ≈ 45; EoMT baseline ≈ 30. Teacher inference is 8.6× slower than EoMT and needs 4.2× the peak memory — the teacher is not presented as deployable; the ViT-L student matches EoMT's inference cost.

---

## Metrics and statistics (Section VI-C)

Dice, IoU, HD95 (pixels @ 896×896), Boundary IoU, ECE, and `E_art` (feature-artifact spectral energy relative to single-encoder EoMT). Significance: two-sided Wilcoxon signed-rank on per-image differences with Holm correction across datasets; effect size is the matched-pairs rank-biserial `r` with a 10 000-resample bootstrap CI. Implemented in `patchconsensus/metrics.py` and `experiments/aggregate_seeds.py`.
